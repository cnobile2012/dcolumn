--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.12
-- Dumped by pg_dump version 9.5.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id;
ALTER TABLE ONLY public.dcolumns_keyvalue DROP CONSTRAINT dcolumns_k_collection_id_c4318c38_fk_dcolumns_collectionbase_id;
ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column DROP CONSTRAINT dcolumns_dynamiccolumn_id_066bf886_fk_dcolumns_dynamiccolumn_id;
ALTER TABLE ONLY public.dcolumns_collectionbase DROP CONSTRAINT dcolumns_collectionbase_column_collection_id_fkey;
ALTER TABLE ONLY public.dcolumns_keyvalue DROP CONSTRAINT dcolumn_dynamic_column_id_a06dd8eb_fk_dcolumns_dynamiccolumn_id;
ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column DROP CONSTRAINT dc_columncollection_id_f42856de_fk_dcolumns_columncollection_id;
ALTER TABLE ONLY public.books_publisher DROP CONSTRAINT books_publisher_collectionbase_ptr_id_fkey;
ALTER TABLE ONLY public.books_promotion DROP CONSTRAINT books_promotion_collectionbase_ptr_id_fkey;
ALTER TABLE ONLY public.books_book DROP CONSTRAINT books_book_collectionbase_ptr_id_fkey;
ALTER TABLE ONLY public.books_author DROP CONSTRAINT books_author_collectionbase_ptr_id_fkey;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.dcolumns_keyvalue_dynamic_column_id;
DROP INDEX public.dcolumns_keyvalue_collection_id;
DROP INDEX public.dcolumns_dynamiccolumn_updater_id;
DROP INDEX public.dcolumns_dynamiccolumn_slug_like;
DROP INDEX public.dcolumns_dynamiccolumn_slug;
DROP INDEX public.dcolumns_dynamiccolumn_preferred_slug_like;
DROP INDEX public.dcolumns_dynamiccolumn_preferred_slug;
DROP INDEX public.dcolumns_dynamiccolumn_creator_id;
DROP INDEX public.dcolumns_columncollection_updater_id;
DROP INDEX public.dcolumns_columncollection_name_like;
DROP INDEX public.dcolumns_columncollection_dynamic_column_dynamiccolumn_id;
DROP INDEX public.dcolumns_columncollection_dynamic_column_columncollection_id;
DROP INDEX public.dcolumns_columncollection_creator_id;
DROP INDEX public.dcolumns_collectionbase_updater_id;
DROP INDEX public.dcolumns_collectionbase_creator_id;
DROP INDEX public.dcolumns_collectionbase_column_collection_id;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_domain_a2e37b91_uniq;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.dcolumns_keyvalue DROP CONSTRAINT dcolumns_keyvalue_pkey;
ALTER TABLE ONLY public.dcolumns_dynamiccolumn DROP CONSTRAINT dcolumns_dynamiccolumn_pkey;
ALTER TABLE ONLY public.dcolumns_columncollection DROP CONSTRAINT dcolumns_columncollection_related_model_key;
ALTER TABLE ONLY public.dcolumns_columncollection DROP CONSTRAINT dcolumns_columncollection_pkey;
ALTER TABLE ONLY public.dcolumns_columncollection DROP CONSTRAINT dcolumns_columncollection_name_key;
ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column DROP CONSTRAINT dcolumns_columncollection_dynamic_column_pkey;
ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column DROP CONSTRAINT dcolumns_columncollection_dyn_columncollection_id_dynamicco_key;
ALTER TABLE ONLY public.dcolumns_collectionbase DROP CONSTRAINT dcolumns_collectionbase_pkey;
ALTER TABLE ONLY public.books_publisher DROP CONSTRAINT books_publisher_pkey;
ALTER TABLE ONLY public.books_promotion DROP CONSTRAINT books_promotion_pkey;
ALTER TABLE ONLY public.books_book DROP CONSTRAINT books_book_pkey;
ALTER TABLE ONLY public.books_author DROP CONSTRAINT books_author_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_key;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.django_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dcolumns_keyvalue ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dcolumns_dynamiccolumn ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dcolumns_columncollection_dynamic_column ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dcolumns_columncollection ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dcolumns_collectionbase ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.django_site_id_seq;
DROP TABLE public.django_site;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.dcolumns_keyvalue_id_seq;
DROP TABLE public.dcolumns_keyvalue;
DROP SEQUENCE public.dcolumns_dynamiccolumn_id_seq;
DROP TABLE public.dcolumns_dynamiccolumn;
DROP SEQUENCE public.dcolumns_columncollection_id_seq;
DROP SEQUENCE public.dcolumns_columncollection_dynamic_column_id_seq;
DROP TABLE public.dcolumns_columncollection_dynamic_column;
DROP TABLE public.dcolumns_columncollection;
DROP SEQUENCE public.dcolumns_collectionbase_id_seq;
DROP TABLE public.dcolumns_collectionbase;
DROP TABLE public.books_publisher;
DROP TABLE public.books_promotion;
DROP TABLE public.books_book;
DROP TABLE public.books_author;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO dcolumn;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO dcolumn;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO dcolumn;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO dcolumn;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO dcolumn;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO dcolumn;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO dcolumn;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO dcolumn;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO dcolumn;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO dcolumn;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO dcolumn;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO dcolumn;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: books_author; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.books_author (
    collectionbase_ptr_id integer NOT NULL,
    name character varying(250) NOT NULL
);


ALTER TABLE public.books_author OWNER TO dcolumn;

--
-- Name: books_book; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.books_book (
    collectionbase_ptr_id integer NOT NULL,
    title character varying(250) NOT NULL
);


ALTER TABLE public.books_book OWNER TO dcolumn;

--
-- Name: books_promotion; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.books_promotion (
    collectionbase_ptr_id integer NOT NULL,
    name character varying(250) NOT NULL
);


ALTER TABLE public.books_promotion OWNER TO dcolumn;

--
-- Name: books_publisher; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.books_publisher (
    collectionbase_ptr_id integer NOT NULL,
    name character varying(250) NOT NULL
);


ALTER TABLE public.books_publisher OWNER TO dcolumn;

--
-- Name: dcolumns_collectionbase; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.dcolumns_collectionbase (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    column_collection_id integer NOT NULL
);


ALTER TABLE public.dcolumns_collectionbase OWNER TO dcolumn;

--
-- Name: dcolumns_collectionbase_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.dcolumns_collectionbase_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_collectionbase_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_collectionbase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.dcolumns_collectionbase_id_seq OWNED BY public.dcolumns_collectionbase.id;


--
-- Name: dcolumns_columncollection; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.dcolumns_columncollection (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    name character varying(50) NOT NULL,
    related_model character varying(50) NOT NULL
);


ALTER TABLE public.dcolumns_columncollection OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_dynamic_column; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.dcolumns_columncollection_dynamic_column (
    id integer NOT NULL,
    columncollection_id integer NOT NULL,
    dynamiccolumn_id integer NOT NULL
);


ALTER TABLE public.dcolumns_columncollection_dynamic_column OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_dynamic_column_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.dcolumns_columncollection_dynamic_column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_columncollection_dynamic_column_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_dynamic_column_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.dcolumns_columncollection_dynamic_column_id_seq OWNED BY public.dcolumns_columncollection_dynamic_column.id;


--
-- Name: dcolumns_columncollection_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.dcolumns_columncollection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_columncollection_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.dcolumns_columncollection_id_seq OWNED BY public.dcolumns_columncollection.id;


--
-- Name: dcolumns_dynamiccolumn; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.dcolumns_dynamiccolumn (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    value_type integer NOT NULL,
    relation integer,
    required boolean NOT NULL,
    store_relation boolean NOT NULL,
    location character varying(50) NOT NULL,
    "order" smallint NOT NULL,
    preferred_slug character varying(50)
);


ALTER TABLE public.dcolumns_dynamiccolumn OWNER TO dcolumn;

--
-- Name: dcolumns_dynamiccolumn_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.dcolumns_dynamiccolumn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_dynamiccolumn_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_dynamiccolumn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.dcolumns_dynamiccolumn_id_seq OWNED BY public.dcolumns_dynamiccolumn.id;


--
-- Name: dcolumns_keyvalue; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.dcolumns_keyvalue (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    dynamic_column_id integer NOT NULL,
    value text
);


ALTER TABLE public.dcolumns_keyvalue OWNER TO dcolumn;

--
-- Name: dcolumns_keyvalue_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.dcolumns_keyvalue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_keyvalue_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_keyvalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.dcolumns_keyvalue_id_seq OWNED BY public.dcolumns_keyvalue.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO dcolumn;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO dcolumn;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO dcolumn;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO dcolumn;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO dcolumn;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO dcolumn;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO dcolumn;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: dcolumn
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO dcolumn;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO dcolumn;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_collectionbase ALTER COLUMN id SET DEFAULT nextval('public.dcolumns_collectionbase_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection ALTER COLUMN id SET DEFAULT nextval('public.dcolumns_columncollection_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column ALTER COLUMN id SET DEFAULT nextval('public.dcolumns_columncollection_dynamic_column_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_dynamiccolumn ALTER COLUMN id SET DEFAULT nextval('public.dcolumns_dynamiccolumn_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_keyvalue ALTER COLUMN id SET DEFAULT nextval('public.dcolumns_keyvalue_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add Dynamic Column	7	add_dynamiccolumn
20	Can change Dynamic Column	7	change_dynamiccolumn
21	Can delete Dynamic Column	7	delete_dynamiccolumn
22	Can add Column Collection	8	add_columncollection
23	Can change Column Collection	8	change_columncollection
24	Can delete Column Collection	8	delete_columncollection
25	Can add collection base	9	add_collectionbase
26	Can change collection base	9	change_collectionbase
27	Can delete collection base	9	delete_collectionbase
28	Can add Key Value	10	add_keyvalue
29	Can change Key Value	10	change_keyvalue
30	Can delete Key Value	10	delete_keyvalue
31	Can add Promotion	11	add_promotion
32	Can change Promotion	11	change_promotion
33	Can delete Promotion	11	delete_promotion
34	Can add Author	12	add_author
35	Can change Author	12	change_author
36	Can delete Author	12	delete_author
37	Can add Publisher	13	add_publisher
38	Can change Publisher	13	change_publisher
39	Can delete Publisher	13	delete_publisher
40	Can add Book	14	add_book
41	Can change Book	14	change_book
42	Can delete Book	14	delete_book
43	Can add site	15	add_site
44	Can change site	15	change_site
45	Can delete site	15	delete_site
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 45, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$100000$szpU8t1KLgB8$5WUm7fEf/lHYJ0ZFLDa9ukGdPdv25x9BvqlSyAYNbog=	2018-04-20 15:14:20.311376+00	t	dcolumn				t	t	2014-09-10 01:27:46.632029+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: books_author; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.books_author (collectionbase_ptr_id, name) FROM stdin;
7	Richard Stones
5	John Iovine
15	Ruth Suehle & Tom Callaway
17	Jeremy Blum
23	Lauren Darcey & Shane Conder
8	Toby Segaran
25	Peter Gasston
28	Paul Horowitz
34	Jim Webber
31	Elliot Williams
6	Rajaram Regupathy
43	Nishant Shukla
36	Michael S. Mikowski
\.


--
-- Data for Name: books_book; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.books_book (collectionbase_ptr_id, title) FROM stdin;
12	Robots, Androids, and Animatrons
9	Collective Intelligence
10	Beginning Linux Programming 2nd Edition
16	Raspberry Pi Hacks
11	Bootstrap Yourself with Linux-USB Stack
27	The Book of CSS3
30	The Art of Electronics
19	Exploring Arduino
35	REST in Practice
33	Make: AVR Programming
45	Machine Learning with TensorFlow
38	Android Wireless Application Development
\.


--
-- Data for Name: books_promotion; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.books_promotion (collectionbase_ptr_id, name) FROM stdin;
13	50% Discount on "Collective Intelligence" eBook
14	50% Discount on "Robots, Androids, and Animatrons" eBook
22	50% Discount on "Android Wireless Application Development" eBook
\.


--
-- Data for Name: books_publisher; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.books_publisher (collectionbase_ptr_id, name) FROM stdin;
3	Cengage Learning, Inc.
2	Wrox Press Inc.
26	No Starch Press, Inc.
29	Cambridge University Press
32	Maker Media, Inc.
1	O'Reilly Media, Inc.
18	John Wiley & Sons, Inc.
21	Addison Wesley Publishing Company
4	The McGraw-Hill Companies, Corp.
44	Manning Publications Co.
\.


--
-- Data for Name: dcolumns_collectionbase; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.dcolumns_collectionbase (id, updater_id, creator_id, created, updated, active, column_collection_id) FROM stdin;
7	1	1	2014-11-15 04:51:25.789147+00	2014-11-15 04:51:25.78916+00	t	4
12	1	1	2014-11-15 16:29:29.712069+00	2014-11-15 17:07:48.130022+00	t	1
9	1	1	2014-11-15 05:21:22.781496+00	2014-11-15 21:01:50.121634+00	t	1
3	1	1	2014-11-15 04:27:56.169267+00	2014-11-28 23:26:23.140785+00	t	2
5	1	1	2014-11-15 04:48:58.377693+00	2014-11-30 06:24:15.981603+00	t	4
2	1	1	2014-11-15 04:24:22.586565+00	2014-11-30 06:26:03.556551+00	t	2
10	1	1	2014-11-15 16:01:20.214021+00	2014-11-30 06:26:18.536172+00	t	1
13	1	1	2014-12-06 18:38:14.134344+00	2014-12-06 18:55:35.246263+00	t	5
14	1	1	2014-12-06 19:04:14.618697+00	2014-12-06 21:57:48.668552+00	f	5
15	1	1	2014-12-06 22:01:34.757801+00	2014-12-06 22:05:05.927726+00	t	4
16	1	1	2014-12-06 22:13:38.539197+00	2014-12-06 22:14:39.094575+00	t	1
17	1	1	2014-12-07 03:06:57.357528+00	2014-12-07 03:07:40.011391+00	t	4
23	1	1	2014-12-07 04:36:30.103437+00	2014-12-07 04:36:30.103452+00	t	4
8	1	1	2014-11-15 04:52:02.800233+00	2014-12-07 22:39:59.047888+00	t	4
11	1	1	2014-11-15 16:21:46.33667+00	2014-12-07 22:47:21.094396+00	t	1
25	1	1	2016-01-01 21:47:02.514457+00	2016-01-01 21:47:02.514466+00	t	4
26	1	1	2016-01-01 21:49:40.352002+00	2016-01-01 21:49:40.352014+00	t	2
38	1	1	2017-12-11 16:06:01.934917+00	2018-03-17 19:12:50.871614+00	t	1
27	1	1	2016-01-01 21:55:24.243423+00	2016-02-10 01:13:56.762667+00	t	1
28	1	1	2016-03-12 01:58:10.547688+00	2016-03-12 01:58:10.547701+00	t	4
29	1	1	2016-03-12 04:12:00.148209+00	2016-03-12 04:12:00.148223+00	t	2
30	1	1	2016-03-12 04:40:40.92458+00	2016-03-13 00:57:12.496906+00	t	1
19	1	1	2014-12-07 03:27:51.593244+00	2016-03-18 01:54:03.051072+00	t	1
32	1	1	2016-03-25 01:15:58.745194+00	2016-03-25 01:15:58.745205+00	t	2
35	1	1	2016-03-27 00:56:06.18283+00	2016-03-27 00:56:18.630659+00	t	1
34	1	1	2016-03-27 00:50:12.100483+00	2016-03-27 00:56:32.416166+00	t	4
1	1	1	2014-11-15 03:47:21.049805+00	2016-03-27 00:56:45.255377+00	t	2
18	1	1	2014-12-07 03:11:41.770398+00	2017-12-17 03:06:13.515525+00	t	2
31	1	1	2016-03-25 01:12:55.241073+00	2018-02-04 21:30:44.188142+00	t	4
21	1	1	2014-12-07 04:29:34.165461+00	2018-02-04 21:31:02.756191+00	t	2
22	1	1	2014-12-07 04:34:13.796066+00	2018-02-04 21:31:31.885096+00	t	5
33	1	1	2016-03-25 01:18:41.926684+00	2017-12-25 21:12:39.961968+00	t	1
6	1	1	2014-11-15 04:50:12.471836+00	2018-02-09 00:52:17.674395+00	t	4
4	1	1	2014-11-15 04:41:16.508678+00	2018-02-09 00:52:30.971607+00	t	2
43	1	1	2018-02-25 02:15:28.985551+00	2018-02-25 02:15:28.985564+00	t	4
44	1	1	2018-02-25 02:18:57.097128+00	2018-02-25 02:18:57.097202+00	t	2
45	1	1	2018-02-25 02:24:53.097826+00	2018-02-25 02:24:53.097836+00	t	1
36	1	1	2017-09-26 01:24:05.108718+00	2018-03-10 02:00:04.277955+00	t	4
\.


--
-- Name: dcolumns_collectionbase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.dcolumns_collectionbase_id_seq', 45, true);


--
-- Data for Name: dcolumns_columncollection; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.dcolumns_columncollection (id, updater_id, creator_id, created, updated, active, name, related_model) FROM stdin;
4	1	1	2014-09-11 01:16:50.206255+00	2016-03-26 20:15:47.961218+00	t	Author Current	author
2	1	1	2014-09-10 19:53:48.019368+00	2016-03-26 20:28:11.45686+00	t	Publisher Current	publisher
5	1	1	2014-12-06 04:56:40.520661+00	2016-03-26 20:33:36.671036+00	t	Promotion Current	promotion
1	1	1	2014-09-10 03:08:48.242518+00	2016-03-26 22:26:43.248161+00	t	Book Current	book
\.


--
-- Data for Name: dcolumns_columncollection_dynamic_column; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.dcolumns_columncollection_dynamic_column (id, columncollection_id, dynamiccolumn_id) FROM stdin;
127	5	25
128	5	26
129	5	27
130	5	28
131	5	29
36	4	18
90	2	12
91	2	13
92	2	14
93	2	15
94	2	16
95	2	17
96	2	21
97	2	24
111	1	2
112	1	3
113	1	6
114	1	7
115	1	8
116	1	9
117	1	10
118	1	11
119	1	19
120	1	20
121	1	22
122	1	23
\.


--
-- Name: dcolumns_columncollection_dynamic_column_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.dcolumns_columncollection_dynamic_column_id_seq', 131, true);


--
-- Name: dcolumns_columncollection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.dcolumns_columncollection_id_seq', 5, true);


--
-- Data for Name: dcolumns_dynamiccolumn; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.dcolumns_dynamiccolumn (id, updater_id, creator_id, created, updated, active, name, slug, value_type, relation, required, store_relation, location, "order", preferred_slug) FROM stdin;
22	1	1	2014-11-15 16:05:54.114142+00	2015-12-30 17:41:38.572825+00	t	Author	author	2	3	t	f	book_top	1	author
23	1	1	2014-11-15 16:06:18.473866+00	2015-12-30 17:41:38.622603+00	t	Publisher	publisher	2	4	t	f	book_top	2	publisher
3	1	1	2014-09-10 02:11:00.117325+00	2015-12-30 17:41:38.6733+00	t	Abstract	abstract	8	\N	f	f	book_top	3	
6	1	1	2014-09-10 02:21:22.517697+00	2015-12-30 17:41:38.756276+00	t	Edition	edition	6	\N	f	f	book_center	1	edition
20	1	1	2014-09-13 02:44:04.159034+00	2015-12-30 17:41:38.939781+00	t	Language	language	2	1	f	f	book_center	6	language
19	1	1	2014-09-13 02:39:49.934608+00	2015-12-30 17:41:38.972855+00	t	Promotion	promotion	2	2	f	t	book_bottom	1	promotion
14	1	1	2014-09-10 19:52:28.022632+00	2015-12-30 17:45:12.466944+00	t	City	city	7	\N	f	f	publisher_top	3	
15	1	1	2014-09-10 19:52:46.695098+00	2015-12-30 17:45:12.500476+00	t	State	state	7	\N	f	f	publisher_top	4	
16	1	1	2014-09-10 19:53:07.490947+00	2015-12-30 17:45:12.550378+00	t	Country	country	7	\N	f	f	publisher_top	5	
18	1	1	2014-09-11 00:55:56.897085+00	2017-09-26 01:25:33.302633+00	t	Web Site	author_url	7	0	f	f	author_top	1	author_url
26	1	1	2014-12-06 04:57:58.245737+00	2017-09-27 00:33:16.751724+00	t	Description	promotion_description	8	0	f	f	promotion_top	1	promotion_description
27	1	1	2014-12-06 04:58:46.589174+00	2017-09-27 00:33:54.348305+00	t	Promotion Start Date	promotion_start_date	3	0	t	f	promotion_top	2	promotion_start_date
25	1	1	2014-12-06 04:38:30.189545+00	2017-09-27 00:34:30.267269+00	t	Promotion Start Time	promotion_start_time	9	0	t	f	promotion_top	3	promotion_start_time
28	1	1	2014-12-06 05:08:35.005268+00	2017-09-27 00:34:59.262549+00	t	Promotion End Date	promotion_end_date	3	0	t	f	promotion_top	4	promotion_end_date
29	1	1	2014-12-06 05:09:24.052767+00	2017-09-27 00:36:52.181342+00	t	Promotion End Time	promotion_end_time	9	0	t	f	promotion_top	5	promotion_end_time
12	1	1	2014-09-10 19:51:50.120345+00	2017-09-27 00:51:58.945421+00	t	Address 1	address_1	7	0	f	f	publisher_top	1	address_1
13	1	1	2014-09-10 19:52:12.799135+00	2017-09-27 00:54:33.130986+00	t	Address 2	address_2	7	0	f	f	publisher_top	2	address_2
17	1	1	2014-09-10 19:56:03.291247+00	2017-09-27 00:57:56.898974+00	t	Postal Code	postal_code	7	0	f	f	publisher_top	6	postal_code
9	1	1	2014-09-10 02:23:31.76202+00	2017-09-27 01:00:52.454263+00	t	SKU	book_sku	7	0	f	f	book_bottom	2	book_sku
2	1	1	2014-09-10 02:10:21.507397+00	2017-09-27 01:01:06.36696+00	t	Published Date	published_date	3	0	f	f	book_center	2	published_date
7	1	1	2014-09-10 02:21:54.515496+00	2017-09-27 01:01:20.627921+00	t	Copyright Year	copyright_year	6	0	f	f	book_center	3	copyright_year
10	1	1	2014-09-10 02:24:22.178165+00	2017-09-27 01:01:44.581758+00	t	ISBN-10	isbn10	7	0	f	f	book_center	4	isbn10
11	1	1	2014-09-10 02:24:43.505707+00	2017-09-27 01:01:56.240155+00	t	ISBN-13	isbn13	7	0	f	f	book_center	5	isbn13
8	1	1	2014-09-10 02:22:45.074184+00	2017-09-27 01:02:18.971368+00	t	Number of Pages	number_of_pages	6	0	f	f	book_top	4	number_of_pages
24	1	1	2014-11-28 22:41:38.181917+00	2017-09-27 01:03:06.328291+00	t	Phone	publisher_phone	7	0	f	f	publisher_center	1	publisher_phone
21	1	1	2014-11-15 03:24:27.91203+00	2017-09-27 01:03:19.173441+00	t	Web Site	publisher_url	7	0	f	f	publisher_center	2	publisher_url
\.


--
-- Name: dcolumns_dynamiccolumn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.dcolumns_dynamiccolumn_id_seq', 29, true);


--
-- Data for Name: dcolumns_keyvalue; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.dcolumns_keyvalue (id, collection_id, dynamic_column_id, value) FROM stdin;
72	5	18	
49	11	8	320
50	11	2	2011-03-17
35	10	8	1008
51	11	7	2012
52	11	10	1-4354-5786-2
53	11	11	978-1-4354-5786-7
54	11	20	2
55	11	19	0
27	9	8	335
56	12	22	5
57	12	23	4
58	12	3	Starting with the novice level and progressing to medium-level complexity; author John Iovine leads readers through the construction of 12 state-of-the-art robotics projects, which provides the foundations and experience for building advanced robotic projects. After outlining how to modify base platforms for locomotion, the author provides detailed information on various types of robotic sensors, including tilt, bump, and road and wall detectors. He illustrates how to implement two different types of robotic intelligence-expert and neural. The remainder of the book focuses on specific, hands-on projects, including a functional, life-like android hand created with a soft rubber material and nitinol wire; a robotic "insect" controlled with a single-board computer programmed in BASIC; and a land rover robot with telepresence systems.
59	12	8	332
60	12	6	2
61	12	2	2001-10-29
62	12	7	2002
63	12	10	0-07-137683-6
64	12	20	2
65	12	19	50% Discount on "Robots, Androids, and Animatrons" eBook
44	9	22	8
45	9	23	1
28	9	3	Want to tap the power behind search rankings, product recommendations, social bookmarking, and online matchmaking? This fascinating book demonstrates how you can build Web 2.0 applications to mine the enormous amount of data created by people on the Internet. With the sophisticated algorithms in this book, you can write smart programs to access interesting datasets from other web sites, collect data from users of your own applications, and analyze and understand the data once you've found it.
26	9	6	1
30	9	2	2007-08-01
31	9	7	2007
32	9	11	978-0-596-52932-1
29	9	20	2
33	9	19	50% Discount on "Collective Intelligence" eBook
14	3	12	20 Channel Center Street
70	3	13	
15	3	14	Boston
16	3	15	MA
17	3	16	United States
18	3	17	02210
71	3	24	(800) 354-9706
19	3	21	www.cengage.com
42	10	22	7
7	2	12	29 S. LaSalle St.
8	2	13	Suite 520
9	2	14	Chicago
10	2	15	Illinois
11	2	16	USA
12	2	17	60603
73	2	24	
13	2	21	www.wrox.com
43	10	23	2
34	10	6	2
38	10	2	2000-07-01
39	10	7	1999
40	10	10	1-861002-97-1
37	10	20	2
41	10	19	0
46	11	22	6
47	11	23	3
48	11	3	Learn to design, develop, and validate USB systems with ease, using this valuable resource that provides a detailed bootstrap session on the Linux-USB design and implementation. BOOTSTRAP YOURSELF WITH LINUX-USB STACK offers a tour of the Linux-USB stack, explaining how to develop drivers for USB device and host controllers on Linux. It moves on to explore the interfaces and data structures of a USB module with UML diagrams, concluding each chapter with a sample implementation that applies the information just covered. A comprehensive look at the various tools and methods available on Linux to validate a USB system is also provided. Using a straightforward writing style, this book is a powerful tool for anyone learning to develop a protocol stack with proper architecture and design, ultimately leading to better quality, maintainability, and testability.
67	1	24	(800) 998-9938
6	1	21	www.oreilly.com
1	1	12	1005 Gravenstein Highway North
66	1	13	
2	1	14	Sebastopol
3	1	15	CA
4	1	16	United States
5	1	17	95472
36	10	3	If you've installed Linux, or have access to a version of UNIX, you've probably gotten used to the environment and its configuration, but if you want to start programming, most Linux books leave you on your own. This book takes off where they stop, showing you how to make the most of the tools UNIX offers (which are included as standard with any distribution of Linux) and start programming UNIX for real.\r\n\r\nBeginning Linux Programming, 2nd Edition, concentrates on C programming, looking at the GNU tools, and the UNIX C libraries, to teach you step by step how to write, build, and debug serious application code. Throughout the book, you develop a fully featured CD Database application, allowing you to see the theory of each new topic applied to a real application. As well as handling basic file operations, input and output and dealing with the way UNIX handles data, you discover such advanced topics as inter-process communication, networking, and using CGI scripting to build a Web interface — all the elements of client-server programming. You are also introduced the GTK+ and you find out how to build rich graphical user interfaces for X with GNOME. Finally, there's an introduction to device drivers, to give you a window into the way the Linux kernel itself works.
74	10	11	
75	10	9	
76	13	26	One day sale.
77	13	27	2014-12-01
78	13	25	00:00
79	13	28	2014-12-02
80	13	29	00:00
106	18	24	
107	18	21	www.wiley.com
121	21	13	
123	21	15	MA
125	21	17	2210
120	21	12	
126	21	24	
122	21	14	Boston
23	4	16	USA
24	4	17	10121-2298
21	4	14	New York
20	4	12	Two Penn Plaza
22	4	15	New York
25	4	21	www.mheducation.com
69	4	24	(800) 262-4729
68	4	13	
244	43	18	
133	23	18	
81	14	26	One day sale.
82	14	27	2001-01-01
83	14	25	00:00
84	14	28	2001-01-02
85	14	29	00:00
86	15	18	
87	16	22	15
88	16	23	1
89	16	3	With more than 60 practical and creative hacks, this book helps you turn Raspberry Pi into the centerpiece of some cool electronics projects. Want to create a controller for a camera or a robot? Set up Linux distributions for media centers or PBX phone systems? That’s just the beginning of what you’ll find inside Raspberry Pi Hacks.
90	16	8	394
91	16	6	1
92	16	2	2013-12-01
93	16	7	2014
94	16	10	
95	16	11	978-1-449-36234-8
96	16	20	2
97	16	19	0
98	16	9	
99	17	18	www.jeremyblum.com
100	18	12	10475 Crosspoint Boulevard
101	18	13	
102	18	14	Indianapolis
103	18	15	IN
104	18	16	United States
105	18	17	46256
118	19	19	
119	19	9	
112	19	6	1
113	19	2	
114	19	7	2013
115	19	10	
116	19	11	978-1-118-54936-0
117	19	20	2
108	19	22	17
109	19	23	18
110	19	3	Exploring Arduino uses the popular Arduino microcontroller platform as an instrument to teach topics in electrical engineering, programming, and human-computer interaction. The book shares best practices in programming and design that you can apply to any project, and code snippets and schematics that will serve as a useful references for future projects even after you’ve mastered all the topics in the book.
111	19	8	384
182	30	2	2015-01-01
146	8	18	
147	11	6	
148	11	9	
149	25	18	https://www.broken-links.com/
150	26	24	415-863-9900
151	26	21	www.nostarch.com
152	26	12	245 8th Street
153	26	13	
154	26	14	San Francisco
155	26	15	CA
156	26	16	USA
157	26	17	94103
158	27	19	0
159	27	9	
160	27	6	2
161	27	2	2014-11-01
162	27	7	2015
163	27	10	1-59327-286-3
164	27	11	978-1-59327-286-9
165	27	20	2
166	27	22	25
167	27	23	26
168	27	3	CSS3 is the technology behind most of the eye-catching visuals on the Web. But the docs can be dry, murky, and full of dastardly caveats for inconsistent browser implementations.\r\n\r\nThis completely updated second edition of the best-selling Book of CSS3 distills the dense technical language of the CSS3 specification into plain English and shows you what CSS3 can do now, in all major browsers. You'll find fully revised coverage of the updated syntax of gradients, grids, and flexible box layout, as well as all-new chapters on values and sizing, and graphical effects like filter effects and blend modes.\r\n
169	27	8	279
170	28	18	
171	29	24	
172	29	21	www.cambridge.org
173	29	12	32 Avenue of the Americas
174	29	13	
175	29	14	New York
176	29	15	NY
177	29	16	USA
178	29	17	10013-2473
179	30	19	
180	30	9	
181	30	6	3
183	30	7	2015
184	30	10	
185	30	11	978-0-521-80926-9
186	30	20	2
187	30	22	28
188	30	23	29
130	22	25	00:00:00
132	22	29	00:00:00
129	22	27	2012-03-15
128	22	26	One day sale.
131	22	28	2012-03-16
189	30	3	The book covers many areas of electronics design, from basic DC voltage, current, and resistance, to active filters and oscillators, to digital electronics, including microprocessors and digital bus interfacing. It also includes discussions of such often-neglected areas as high-frequency, high-speed design techniques and low-power applications.\r\n\r\nThe book includes many example circuits. In addition to having examples of good circuits, it also has examples of bad ideas, with discussions of what makes the good designs good and the bad ones bad. It can be described as a cross between a textbook and reference manual, though without the chapter-end questions and exercises which are often found in textbooks.\r\n\r\nThere is also a complementary text, Student Manual for The Art of Electronics by Thomas C. Hayes and Paul Horowitz. The Student Manual, while referring to the main text extensively, is designed specifically to teach electronics. It contains laboratory exercises and explanatory text supplements aimed at the student. In contrast, The Art of Electronics contains tables, equations, diagrams, and other material practitioners use for reference.
190	30	8	1192
192	32	24	800-998-9938
193	32	21	
194	32	12	1160 Battery Street East
195	32	13	Suite 125
196	32	14	San Francisco
197	32	15	CA
198	32	16	USA
199	32	17	94111
201	33	9	
202	33	6	1
203	33	2	2014-02-01
204	33	7	2014
205	33	10	
206	33	11	978-1-449-35578-4
208	33	22	31
209	33	23	32
210	33	3	
211	33	8	454
213	35	19	
214	35	9	
215	35	6	1
216	35	2	2010-01-01
217	35	7	2010
218	35	10	
219	35	11	978-0-596-80582-1
220	35	20	2
221	35	22	34
222	35	23	1
223	35	3	A great example of success is the World Wide Web. Its success has penetrated both\r\nbusiness operations and popular culture. It provides opportunities for people to pull\r\ntogether information from many sources, with hardly any prearranged collaboration—\r\nand at a global scale.\r\nThe Web, as we currently know it, isn’t the be-all and end-all of computing, but many\r\npeople believe it offers an important lesson on how to construct systems of networked\r\ncomponents. Many people take advantage of its protocol, HTTP, to connect systems.\r\nBut some people think we should go further, using HTTP not as a convenient tunnel,\r\nbut to embrace the way the Web works as a foundation for systems collaboration.\r\nThis thinking gathers together under the name of “REST.” It refers to Roy Fielding’s\r\nPhD thesis, which is far more often referred to than it is read. There is a growing\r\nnotion that following the principles of REST offers a fruitful path to making networked\r\ncomponents work, one that is built upon the success of the Web itself.
224	35	8	428
212	34	18	
245	44	14	Shelter Island
246	44	24	
247	44	21	http://www.manning.com
248	44	15	NY
200	33	19	0
249	44	16	USA
207	33	20	2
250	44	13	
251	44	17	11964
191	31	18	http://github.com/hexagon5un/AVR-Programming
252	44	12	20 Baldwin Road
225	36	18	https://github.com/mmikowski
229	38	6	3
230	38	7	2012
237	38	8	542
234	38	22	23
235	38	23	21
232	38	11	978-0-321-81496-8
238	38	9	123456asd
233	38	20	2
231	38	10	0-321-81496-7
127	21	21	www.pearsonhighered.com
124	21	16	United States
239	6	18	
253	45	22	43
254	45	23	44
255	45	6	1
256	45	19	
257	45	10	
258	45	7	2018
259	45	20	2
260	45	9	
261	45	3	Machine Learning with TensorFlow gives readers a solid foundation in machine-learning concepts plus hands-on experience coding TensorFlow with Python.
262	45	11	9781617293870
263	45	8	272
236	38	3	Android Wireless Application Development has earned a reputation as the most useful real-world guide to building robust, commercial-grade Android apps. Now, authors Lauren Darcey and Shane Conder have systematically revised and updated this guide for the latest Android SDK 4.0. To accommodate their extensive new coverage, they’ve split the book into two volumes. Volume I focuses on Android essentials, including setting up your development environment, understanding the application lifecycle, designing effective user interfaces, developing for diverse devices, and optimizing your mobile app development process--from design through publishing. Every chapter has been thoroughly updated for the newest APIs, tools, utilities, and hardware. All sample code has been overhauled and tested on leading devices from multiple companies, and many new examples have been added. Drawing on decades of in-the-trenches experience as professional mobile developers, Darcey and Conder provide valuable new best practices--including powerful techniques for constructing more portable apps. This new edition contains full chapters on Android manifest files, content providers, effective app design, and testing; an all-new chapter on tackling compatibility issues; coverage of today’s most valuable new Android tools and utilities; and even more exclusive tips and tricks. An indispensable resource for every Android development team member.
240	38	19	
\.


--
-- Name: dcolumns_keyvalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.dcolumns_keyvalue_id_seq', 263, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2014-09-10 01:39:33.968614+00	1	Title	1		7	1
2	2014-09-10 02:10:21.519037+00	2	Published Date	1		7	1
3	2014-09-10 02:11:00.12927+00	3	Abstract	1		7	1
4	2014-09-10 02:11:31.766035+00	4	Purchase Date	1		7	1
5	2014-09-10 02:12:05.645248+00	4	Date Purchase	2	Changed name and relation.	7	1
6	2014-09-10 02:20:00.348272+00	4	Date Purchased	2	Changed name and relation.	7	1
7	2014-09-10 02:20:56.823019+00	5	Purchase Price	1		7	1
8	2014-09-10 02:21:22.528824+00	6	Edition	1		7	1
9	2014-09-10 02:21:54.525687+00	7	Copyright Year	1		7	1
10	2014-09-10 02:22:45.090261+00	8	Pages	1		7	1
11	2014-09-10 02:23:31.772054+00	9	Shelf ID	1		7	1
12	2014-09-10 02:24:22.188944+00	10	ISBN10	1		7	1
13	2014-09-10 02:24:43.512666+00	11	ISBN-13	1		7	1
14	2014-09-10 02:24:58.186149+00	10	ISBN-10	2	Changed name and relation.	7	1
15	2014-09-10 02:25:06.947606+00	10	ISBN-10	2	Changed relation.	7	1
16	2014-09-10 02:30:49.268616+00	6	Edition	2	Changed order.	7	1
17	2014-09-10 02:31:07.893867+00	7	Copyright Year	2	Changed order.	7	1
18	2014-09-10 02:32:20.872843+00	9	Shelf ID	2	Changed location and order.	7	1
19	2014-09-10 02:34:35.371096+00	6	Edition	2	Changed location and order.	7	1
20	2014-09-10 02:34:35.412151+00	2	Published Date	2	Changed location.	7	1
21	2014-09-10 02:34:35.454644+00	3	Abstract	2	Changed order.	7	1
22	2014-09-10 02:34:35.495753+00	7	Copyright Year	2	Changed location.	7	1
23	2014-09-10 02:34:35.528857+00	4	Date Purchased	2	Changed order.	7	1
24	2014-09-10 02:34:35.570874+00	5	Purchase Price	2	Changed order.	7	1
25	2014-09-10 02:34:35.621274+00	8	Pages	2	Changed order.	7	1
26	2014-09-10 02:34:35.662353+00	10	ISBN-10	2	Changed order.	7	1
27	2014-09-10 02:34:35.704116+00	11	ISBN-13	2	Changed order.	7	1
28	2014-09-10 02:34:35.754763+00	9	Shelf ID	2	Changed location and order.	7	1
29	2014-09-10 02:34:56.005179+00	10	ISBN-10	2	Changed location.	7	1
30	2014-09-10 02:34:56.055191+00	11	ISBN-13	2	Changed location.	7	1
31	2014-09-10 02:35:06.263815+00	4	Date Purchased	2	Changed location.	7	1
32	2014-09-10 02:35:55.033787+00	4	Date Purchased	2	Changed location and order.	7	1
33	2014-09-10 02:36:23.609573+00	5	Purchase Price	2	Changed location and order.	7	1
34	2014-09-10 02:36:23.651635+00	8	Pages	2	Changed order.	7	1
35	2014-09-10 02:37:27.878952+00	3	Abstract	2	Changed order.	7	1
36	2014-09-10 02:37:27.895989+00	9	Shelf ID	2	Changed order.	7	1
37	2014-09-10 02:37:27.938258+00	8	Pages	2	Changed order.	7	1
38	2014-09-10 02:37:27.988174+00	6	Edition	2	Changed location and order.	7	1
39	2014-09-10 02:38:05.906206+00	2	Published Date	2	Changed order.	7	1
40	2014-09-10 02:38:05.956198+00	7	Copyright Year	2	Changed order.	7	1
41	2014-09-10 02:38:06.006147+00	10	ISBN-10	2	Changed order.	7	1
42	2014-09-10 02:38:06.039966+00	11	ISBN-13	2	Changed order.	7	1
43	2014-09-10 03:08:48.289898+00	1	Book Current-2014-09-10T03:08:48.242546+00:00	1		8	1
44	2014-09-10 03:11:34.229577+00	1	Title	3		7	1
45	2014-09-10 03:11:53.005706+00	6	Edition	2	Changed order.	7	1
46	2014-09-10 03:11:53.04823+00	3	Abstract	2	Changed order.	7	1
47	2014-09-10 03:11:53.09747+00	9	Shelf ID	2	Changed order.	7	1
48	2014-09-10 03:11:53.130502+00	8	Pages	2	Changed order.	7	1
49	2014-09-10 14:46:16.808045+00	3	Abstract	2	Changed order.	7	1
50	2014-09-10 14:46:16.850615+00	9	Shelf ID	2	Changed order.	7	1
51	2014-09-10 14:46:16.900696+00	8	Pages	2	Changed order.	7	1
52	2014-09-10 14:46:59.389097+00	8	Number of Pages	2	Changed name and relation.	7	1
53	2014-09-10 19:51:50.134996+00	12	Address 1	1		7	1
54	2014-09-10 19:52:12.807505+00	13	Address 2	1		7	1
55	2014-09-10 19:52:28.032094+00	14	City	1		7	1
56	2014-09-10 19:52:46.703669+00	15	State	1		7	1
57	2014-09-10 19:53:07.507321+00	16	Country	1		7	1
58	2014-09-10 19:53:48.056495+00	2	Publisher Current-2014-09-10T19:53:48.019384+00:00	1		8	1
59	2014-09-10 19:56:03.301322+00	17	Postal Code	1		7	1
60	2014-09-10 19:56:28.859398+00	2	Publisher Current-2014-09-10T19:56:28.821174+00:00	2	Changed dynamic_column.	8	1
61	2014-09-10 22:55:25.277139+00	2	Publisher Current-2014-09-10T22:55:25.240698+00:00	2	No fields changed.	8	1
62	2014-09-11 00:43:30.420769+00	2	Publisher Current-2014-09-11T00:43:30.383947+00:00	2	No fields changed.	8	1
63	2014-09-11 00:55:56.906485+00	18	URL	1		7	1
64	2014-09-11 01:12:37.149046+00	3	Author Current-2014-09-11T01:12:37.115966+00:00	1		8	1
65	2014-09-11 01:15:10.660547+00	3	Author Current-2014-09-11T01:12:37.115966+00:00	3		8	1
66	2014-09-11 01:16:50.245355+00	4	Author Current-2014-09-11T01:16:50.206267+00:00	1		8	1
67	2014-09-11 16:23:22.658521+00	18	Web Site URL	2	Changed name and relation.	7	1
68	2014-09-13 02:39:49.946046+00	19	Promotion	1		7	1
69	2014-09-13 02:40:27.27698+00	1	Book Current-2014-09-13T02:40:27.236641+00:00	2	Changed dynamic_column.	8	1
70	2014-09-13 02:40:35.434702+00	1	Book Current-2014-09-13T02:40:35.396951+00:00	2	No fields changed.	8	1
71	2014-09-13 02:41:19.991834+00	19	Promotion	2	Changed relation, location and order.	7	1
72	2014-09-13 02:44:04.169945+00	20	Language	1		7	1
73	2014-09-13 02:44:29.491736+00	1	Book Current-2014-09-13T02:44:29.456317+00:00	2	Changed dynamic_column.	8	1
74	2014-11-12 01:35:41.647318+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
75	2014-11-12 01:35:51.627896+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
76	2014-11-12 01:36:39.075042+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
77	2014-11-12 01:36:52.681611+00	18	Web Site URL POOP	2	Changed name and relation.	7	1
78	2014-11-12 01:37:05.700478+00	18	Web Site URL	2	Changed name and relation.	7	1
79	2014-11-12 01:37:43.143402+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
80	2014-11-12 01:37:53.207807+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
81	2014-11-12 01:38:08.176637+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
82	2014-11-15 03:21:47.607424+00	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
83	2014-11-15 03:22:30.731718+00	18	Web Site	2	Changed name and relation.	7	1
84	2014-11-15 03:24:27.933509+00	21	Web Site	1		7	1
85	2014-11-15 03:25:08.683207+00	2	Publisher Current-2014-11-15T03:25:08.588231+00:00	2	Changed dynamic_column.	8	1
86	2014-11-15 03:43:59.039989+00	1	50% Discount on eBook-2014-11-15T00:00:00-05:00	1		11	1
87	2014-11-15 03:47:21.088933+00	1	O'Reilly Media, Inc.	1		13	1
88	2014-11-15 05:12:39.401601+00	3	Abstract	2	Changed relation.	7	1
89	2014-11-15 05:13:56.652186+00	19	Promotion	2	Changed relation.	7	1
90	2014-11-15 06:20:35.390633+00	4	Date Purchased	3		7	1
91	2014-11-15 06:20:35.429701+00	5	Purchase Price	3		7	1
92	2014-11-15 06:20:54.180662+00	19	Promotion	2	Changed order.	7	1
93	2014-11-15 16:05:54.12218+00	22	Author	1		7	1
94	2014-11-15 16:06:18.481195+00	23	Publisher	1		7	1
95	2014-11-15 16:06:42.018962+00	1	Book Current-2014-11-15T16:06:41.979289+00:00	2	Changed dynamic_column.	8	1
96	2014-11-15 16:08:58.75954+00	6	Edition	2	Changed order.	7	1
97	2014-11-15 16:08:58.792999+00	8	Number of Pages	2	Changed order.	7	1
98	2014-11-15 16:08:58.826154+00	3	Abstract	2	Changed order.	7	1
99	2014-11-15 16:08:58.859346+00	9	Shelf ID	2	Changed order.	7	1
100	2014-11-15 16:08:58.901347+00	20	Language	2	Changed order.	7	1
101	2014-11-15 16:11:25.533571+00	6	Edition	2	Changed location and order.	7	1
102	2014-11-15 16:11:25.575653+00	2	Published Date	2	Changed order.	7	1
103	2014-11-15 16:11:25.608578+00	7	Copyright Year	2	Changed order.	7	1
104	2014-11-15 16:11:25.65091+00	10	ISBN-10	2	Changed order.	7	1
105	2014-11-15 16:11:25.691863+00	11	ISBN-13	2	Changed order.	7	1
106	2014-11-15 16:12:01.376945+00	8	Number of Pages	2	Changed order.	7	1
107	2014-11-15 16:12:01.427863+00	3	Abstract	2	Changed order.	7	1
108	2014-11-15 16:13:01.571778+00	20	Language	2	Changed location and order.	7	1
109	2014-11-15 16:13:40.149196+00	3	Abstract	2	Changed order.	7	1
110	2014-11-15 16:13:40.190133+00	8	Number of Pages	2	Changed order.	7	1
111	2014-11-15 16:13:40.231683+00	9	Shelf ID	2	Changed order.	7	1
112	2014-11-15 16:13:56.666167+00	9	Shelf ID	2	Changed location and order.	7	1
113	2014-11-15 17:02:54.29079+00	1	50% Discount on "Collective Intelligence" eBook-2014-11-15T00:00:00-05:00	2	Changed name.	11	1
114	2014-11-15 17:05:14.976081+00	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T00:00:00-04:00	1		11	1
115	2014-11-15 17:05:49.668228+00	1	50% Discount on "Collective Intelligence" eBook-2014-11-15T00:00:00-05:00	2	Changed description.	11	1
116	2014-11-15 17:06:04.531394+00	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T00:00:00-04:00	2	Changed description.	11	1
117	2014-11-15 17:07:38.282123+00	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T04:00:00+00:00	2	Changed active.	11	1
118	2014-11-15 17:07:59.541262+00	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T04:00:00+00:00	2	Changed active.	11	1
119	2014-11-15 22:54:50.631012+00	9	Stock Unit ID	2	Changed name, relation and preferred_slug.	7	1
120	2014-11-28 05:31:01.705038+00	22	Author	2	Changed relation and preferred_slug.	7	1
121	2014-11-28 05:33:46.974891+00	23	Publisher	2	Changed relation and preferred_slug.	7	1
122	2014-11-28 05:34:37.171441+00	6	Edition	2	Changed relation and preferred_slug.	7	1
123	2014-11-28 05:35:13.513823+00	2	Published Date	2	Changed relation and preferred_slug.	7	1
124	2014-11-28 05:36:01.908415+00	7	Copyright Year	2	Changed relation and preferred_slug.	7	1
125	2014-11-28 05:36:52.615362+00	10	ISBN-10	2	Changed relation and preferred_slug.	7	1
126	2014-11-28 05:37:32.341804+00	11	ISBN-13	2	Changed relation and preferred_slug.	7	1
127	2014-11-28 05:38:02.846827+00	20	Language	2	Changed relation and preferred_slug.	7	1
128	2014-11-28 05:38:31.327903+00	19	Promotion	2	Changed relation and preferred_slug.	7	1
129	2014-11-28 22:41:38.351454+00	24	Phone	1		7	1
130	2014-11-28 22:42:03.965217+00	21	Web Site	2	Changed location and order.	7	1
131	2014-11-28 22:42:16.169207+00	2	Publisher Current-2014-11-28T22:42:16.087407+00:00	2	Changed dynamic_column.	8	1
132	2014-11-28 23:10:08.722458+00	2	Wrox Press Inc.	2	Changed value for Key Value "http://www.wrox.com".	13	1
133	2014-11-28 23:25:27.098331+00	2	Wrox Press Inc.	2	Changed value for Key Value "www.wrox.com".	13	1
134	2014-11-28 23:26:07.68691+00	4	The McGraw-Hill Companies, Corp.	2	Changed value for Key Value "www.mheducation.com".	13	1
135	2014-11-28 23:26:23.171496+00	3	Cengage Learning, Inc.	2	Changed value for Key Value "www.cengage.com".	13	1
136	2014-11-28 23:26:34.444478+00	1	O'Reilly Media, Inc.	2	Changed value for Key Value "www.oreilly.com".	13	1
137	2014-12-04 01:12:56.343205+00	8	Number of Pages	2	Changed value_type and relation.	7	1
138	2014-12-04 01:13:07.913869+00	18	Web Site	2	Changed value_type and relation.	7	1
139	2014-12-04 01:13:29.219862+00	3	Abstract	2	Changed value_type and relation.	7	1
140	2014-12-04 01:13:37.085027+00	8	Number of Pages	2	Changed relation.	7	1
141	2014-12-04 01:13:51.189456+00	6	Edition	2	Changed value_type and relation.	7	1
142	2014-12-04 01:14:28.171554+00	7	Copyright Year	2	Changed value_type and relation.	7	1
143	2014-12-04 01:14:41.242787+00	10	ISBN-10	2	Changed value_type and relation.	7	1
144	2014-12-04 01:14:50.69969+00	11	ISBN-13	2	Changed value_type and relation.	7	1
145	2014-12-04 01:15:10.043894+00	9	Stock Unit ID	2	Changed value_type and relation.	7	1
146	2014-12-04 01:15:20.359609+00	12	Address 1	2	Changed value_type and relation.	7	1
147	2014-12-04 01:15:28.900533+00	13	Address 2	2	Changed value_type and relation.	7	1
148	2014-12-04 01:15:38.03869+00	14	City	2	Changed value_type and relation.	7	1
149	2014-12-04 01:15:46.262722+00	15	State	2	Changed value_type and relation.	7	1
150	2014-12-04 01:15:54.213614+00	16	Country	2	Changed value_type and relation.	7	1
151	2014-12-04 01:16:02.086889+00	17	Postal Code	2	Changed value_type and relation.	7	1
152	2014-12-04 01:16:11.024393+00	24	Phone	2	Changed value_type and relation.	7	1
153	2014-12-04 01:16:20.743215+00	21	Web Site	2	Changed value_type and relation.	7	1
154	2014-12-06 04:38:30.200347+00	25	Published Time	1		7	1
155	2014-12-06 04:39:01.174017+00	7	Copyright Year	2	Changed order.	7	1
156	2014-12-06 04:39:01.223899+00	10	ISBN-10	2	Changed order.	7	1
157	2014-12-06 04:39:01.265527+00	11	ISBN-13	2	Changed order.	7	1
158	2014-12-06 04:39:01.299789+00	20	Language	2	Changed order.	7	1
159	2014-12-06 04:39:28.733413+00	1	Book Current-2014-12-06T04:39:28.703938+00:00	2	Changed dynamic_column.	8	1
160	2014-12-06 04:40:57.413186+00	25	Published Time	2	Changed order.	7	1
161	2014-12-06 04:40:57.446491+00	7	Copyright Year	2	Changed order.	7	1
162	2014-12-06 04:40:57.480066+00	10	ISBN-10	2	Changed order.	7	1
163	2014-12-06 04:40:57.521246+00	11	ISBN-13	2	Changed order.	7	1
164	2014-12-06 04:40:57.563276+00	20	Language	2	Changed order.	7	1
165	2014-12-06 04:41:17.271583+00	1	Book Current-2014-12-06T04:41:17.208638+00:00	2	Changed dynamic_column.	8	1
166	2014-12-06 04:56:40.58924+00	5	Promotion Current-2014-12-06T04:56:40.520678+00:00	1		8	1
167	2014-12-06 04:57:58.257141+00	26	Description	1		7	1
168	2014-12-06 04:58:04.282751+00	26	Description	2	Changed relation.	7	1
169	2014-12-06 04:58:46.598038+00	27	Promotion Date	1		7	1
170	2014-12-06 04:59:28.912671+00	25	Promotion Time	2	Changed name, relation and preferred_slug.	7	1
171	2014-12-06 04:59:51.476624+00	5	Promotion Current-2014-12-06T04:59:51.441807+00:00	2	Changed dynamic_column.	8	1
172	2014-12-06 05:06:59.143412+00	27	Promotion Start Date	2	Changed name, relation and preferred_slug.	7	1
173	2014-12-06 05:07:24.815789+00	25	Promotion Start Time	2	Changed name, relation and preferred_slug.	7	1
174	2014-12-06 05:08:35.015933+00	28	Promotion End Date	1		7	1
175	2014-12-06 05:09:24.059668+00	29	Promotion End Time	1		7	1
176	2014-12-06 05:10:12.023766+00	5	Promotion Current-2014-12-06T05:10:11.987145+00:00	2	Changed dynamic_column.	8	1
177	2014-12-06 18:16:59.937273+00	26	Description	2	Changed order.	7	1
178	2014-12-06 18:16:59.977429+00	27	Promotion Start Date	2	Changed order.	7	1
179	2014-12-06 18:17:00.010805+00	25	Promotion Start Time	2	Changed location and order.	7	1
180	2014-12-06 18:35:33.18124+00	28	Promotion End Date	2	Changed relation and preferred_slug.	7	1
181	2014-12-06 18:35:45.924233+00	29	Promotion End Time	2	Changed relation.	7	1
182	2014-12-06 19:39:46.182445+00	27	Promotion Start Date	2	Changed relation and required.	7	1
183	2014-12-06 19:39:57.043447+00	25	Promotion Start Time	2	Changed relation and required.	7	1
184	2014-12-06 19:40:09.322192+00	28	Promotion End Date	2	Changed relation and required.	7	1
185	2014-12-06 19:40:16.500983+00	29	Promotion End Time	2	Changed relation and required.	7	1
186	2014-12-06 22:05:05.947748+00	15	Ruth Suehle & Tom Callaway	2	Changed active.	12	1
187	2014-12-06 22:14:39.116371+00	16	Raspberry Pi Hacks	2	Changed active.	14	1
188	2014-12-07 03:07:40.051637+00	17	Jeremy Blum	2	Changed active.	12	1
189	2014-12-07 03:29:09.120874+00	19	Exploring Arduino	2	Changed active.	14	1
190	2014-12-07 22:42:50.144891+00	9	SKU	2	Changed name, relation and preferred_slug.	7	1
191	2014-12-07 22:44:14.697802+00	9	SKU	2	Changed relation and preferred_slug.	7	1
192	2015-12-29 17:30:58.787669+00	18	Web Site (author-top)	2	Changed location.	7	1
193	2015-12-29 17:30:58.933075+00	26	Description (promotion-top)	2	Changed location.	7	1
194	2015-12-29 17:30:58.971845+00	27	Promotion Start Date (promotion-top)	2	Changed location.	7	1
195	2015-12-29 17:30:59.013008+00	25	Promotion Start Time (promotion-top)	2	Changed location.	7	1
196	2015-12-29 17:30:59.046508+00	28	Promotion End Date (promotion-top)	2	Changed location.	7	1
197	2015-12-29 17:30:59.079812+00	29	Promotion End Time (promotion-top)	2	Changed location.	7	1
198	2015-12-29 17:30:59.113084+00	12	Address 1 (publisher-top)	2	Changed location.	7	1
199	2015-12-29 17:30:59.154658+00	14	City (publisher-top)	2	Changed location.	7	1
200	2015-12-29 17:30:59.196834+00	15	State (publisher-top)	2	Changed location.	7	1
201	2015-12-29 17:30:59.238271+00	16	Country (publisher-top)	2	Changed location.	7	1
202	2015-12-29 17:30:59.271538+00	17	Postal Code (publisher-top)	2	Changed location.	7	1
203	2015-12-29 17:30:59.313245+00	24	Phone (publisher-center)	2	Changed location.	7	1
204	2015-12-29 17:30:59.363214+00	21	Web Site (publisher-center)	2	Changed location.	7	1
205	2015-12-29 17:32:46.109902+00	13	Address 2 (publisher-top)	2	Changed location.	7	1
206	2015-12-30 03:17:48.132813+00	26	Description (promotion-top)	2	Changed location.	7	1
207	2015-12-30 03:17:48.168333+00	27	Promotion Start Date (promotion-top)	2	Changed location.	7	1
208	2015-12-30 03:17:48.210313+00	25	Promotion Start Time (promotion-top)	2	Changed location.	7	1
209	2015-12-30 03:17:48.251597+00	28	Promotion End Date (promotion-top)	2	Changed location.	7	1
210	2015-12-30 03:17:48.285193+00	29	Promotion End Time (promotion-top)	2	Changed location.	7	1
211	2015-12-30 03:17:48.334924+00	12	Address 1 (publisher-top)	2	Changed location.	7	1
212	2015-12-30 03:17:48.376992+00	14	City (publisher-top)	2	Changed location.	7	1
213	2015-12-30 03:17:48.418478+00	15	State (publisher-top)	2	Changed location.	7	1
214	2015-12-30 03:17:48.451949+00	16	Country (publisher-top)	2	Changed location.	7	1
215	2015-12-30 03:17:48.485023+00	17	Postal Code (publisher-top)	2	Changed location.	7	1
216	2015-12-30 03:17:48.518894+00	24	Phone (publisher-center)	2	Changed location.	7	1
217	2015-12-30 03:17:48.560118+00	21	Web Site (publisher-center)	2	Changed location.	7	1
218	2015-12-30 03:28:10.458672+00	12	Address 1 (publisher-top)	2	Changed location.	7	1
219	2015-12-30 03:28:10.490056+00	14	City (publisher-top)	2	Changed location.	7	1
220	2015-12-30 03:28:10.548413+00	15	State (publisher-top)	2	Changed location.	7	1
221	2015-12-30 03:28:10.581859+00	16	Country (publisher-top)	2	Changed location.	7	1
222	2015-12-30 03:28:10.615106+00	17	Postal Code (publisher-top)	2	Changed location.	7	1
223	2015-12-30 03:28:10.664903+00	24	Phone (publisher-center)	2	Changed location.	7	1
224	2015-12-30 03:28:10.698418+00	21	Web Site (publisher-center)	2	Changed location.	7	1
225	2015-12-30 03:28:10.731593+00	13	Address 2 (publisher-top)	2	Changed location.	7	1
226	2015-12-30 17:41:38.553053+00	18	Web Site (author-top)	2	Changed location.	7	1
227	2015-12-30 17:41:38.597855+00	22	Author (book-top)	2	Changed location.	7	1
228	2015-12-30 17:41:38.647962+00	23	Publisher (book-top)	2	Changed location.	7	1
229	2015-12-30 17:41:38.698298+00	3	Abstract (book-top)	2	Changed location.	7	1
230	2015-12-30 17:41:38.739665+00	8	Number of Pages (book-top)	2	Changed location.	7	1
231	2015-12-30 17:41:38.781203+00	6	Edition (book-center)	2	Changed location.	7	1
232	2015-12-30 17:41:38.822846+00	2	Published Date (book-center)	2	Changed location.	7	1
233	2015-12-30 17:41:38.85674+00	7	Copyright Year (book-center)	2	Changed location.	7	1
234	2015-12-30 17:41:38.889861+00	10	ISBN-10 (book-center)	2	Changed location.	7	1
235	2015-12-30 17:41:38.923071+00	11	ISBN-13 (book-center)	2	Changed location.	7	1
236	2015-12-30 17:41:38.956361+00	20	Language (book-center)	2	Changed location.	7	1
237	2015-12-30 17:41:38.998206+00	19	Promotion (book-bottom)	2	Changed location.	7	1
238	2015-12-30 17:41:39.031489+00	9	SKU (book-bottom)	2	Changed location.	7	1
239	2015-12-30 17:41:39.073067+00	26	Description (promotion-top)	2	Changed location.	7	1
240	2015-12-30 17:41:39.106646+00	27	Promotion Start Date (promotion-top)	2	Changed location.	7	1
241	2015-12-30 17:41:39.148044+00	25	Promotion Start Time (promotion-top)	2	Changed location.	7	1
242	2015-12-30 17:41:39.181326+00	28	Promotion End Date (promotion-top)	2	Changed location.	7	1
243	2015-12-30 17:41:39.222929+00	29	Promotion End Time (promotion-top)	2	Changed location.	7	1
244	2015-12-30 17:41:39.257238+00	24	Phone (publisher-top)	2	Changed location.	7	1
245	2015-12-30 17:41:39.298185+00	21	Web Site (publisher-top)	2	Changed location.	7	1
246	2015-12-30 17:41:39.339823+00	12	Address 1 (publisher-center)	2	Changed location.	7	1
247	2015-12-30 17:41:39.398274+00	13	Address 2 (publisher-center)	2	Changed location.	7	1
248	2015-12-30 17:41:39.431454+00	14	City (publisher-center)	2	Changed location.	7	1
249	2015-12-30 17:41:39.465001+00	15	State (publisher-center)	2	Changed location.	7	1
250	2015-12-30 17:41:39.514668+00	16	Country (publisher-center)	2	Changed location.	7	1
251	2015-12-30 17:41:39.548237+00	17	Postal Code (publisher-center)	2	Changed location.	7	1
252	2015-12-30 17:45:12.413648+00	12	Address 1 (publisher-top)	2	Changed location.	7	1
253	2015-12-30 17:45:12.450492+00	13	Address 2 (publisher-top)	2	Changed location.	7	1
254	2015-12-30 17:45:12.48378+00	14	City (publisher-top)	2	Changed location.	7	1
255	2015-12-30 17:45:12.525225+00	15	State (publisher-top)	2	Changed location.	7	1
256	2015-12-30 17:45:12.566869+00	16	Country (publisher-top)	2	Changed location.	7	1
257	2015-12-30 17:45:12.608597+00	17	Postal Code (publisher-top)	2	Changed location.	7	1
258	2015-12-30 17:45:12.642035+00	24	Phone (publisher-center)	2	Changed location.	7	1
259	2015-12-30 17:45:12.675325+00	21	Web Site (publisher-center)	2	Changed location.	7	1
260	2015-12-30 17:57:04.309839+00	9	SKU (book-bottom)	2	Changed order.	7	1
261	2016-01-02 14:41:31.066505+00	24	Android Wireless Application Development	2	Changed value for Key Value "22". Changed value for Key Value "2012-02-01".	14	1
262	2016-02-10 01:13:30.246688+00	27	The Book of CSS3	2	Changed active.	14	1
263	2016-02-10 01:13:56.825356+00	27	The Book of CSS3	2	Changed active.	14	1
264	2016-03-26 20:15:48.015947+00	4	Author Current-2016-03-26T20:15:47.961218+00:00	2	Changed related_model.	8	1
265	2016-03-26 20:16:21.600443+00	1	Book Current-2016-03-26T20:16:21.547039+00:00	2	Changed related_model.	8	1
266	2016-03-26 20:20:41.815552+00	5	Promotion Current-2016-03-26T20:20:41.758081+00:00	2	Changed related_model.	8	1
267	2016-03-26 20:20:56.756604+00	2	Publisher Current-2016-03-26T20:20:56.702412+00:00	2	Changed related_model.	8	1
268	2016-03-26 20:26:02.2307+00	2	Publisher Current-2016-03-26T20:26:02.136682+00:00	2	No fields changed.	8	1
269	2016-03-26 20:28:11.51651+00	2	Publisher Current-2016-03-26T20:28:11.456860+00:00	2	Changed related_model.	8	1
270	2016-03-26 20:28:37.380128+00	5	Promotion Current-2016-03-26T20:28:37.326244+00:00	2	No fields changed.	8	1
271	2016-03-26 20:29:35.237419+00	5	Promotion Current-2016-03-26T20:29:35.170189+00:00	2	No fields changed.	8	1
272	2016-03-26 20:33:23.246586+00	5	Promotion Current-2016-03-26T20:33:23.154708+00:00	2	No fields changed.	8	1
273	2016-03-26 20:33:36.725256+00	5	Promotion Current-2016-03-26T20:33:36.671036+00:00	2	No fields changed.	8	1
274	2016-03-26 22:26:31.415472+00	1	Book Current-2016-03-26T22:26:31.357914+00:00	2	No fields changed.	8	1
275	2016-03-26 22:26:43.297061+00	1	Book Current-2016-03-26T22:26:43.248161+00:00	2	No fields changed.	8	1
276	2017-09-24 02:09:27.737299+00	31	Elliot Williams	2	[]	12	1
277	2017-09-24 02:10:25.355553+00	21	Addison Wesley Publishing Company	2	[]	13	1
278	2017-09-24 17:32:36.979914+00	24	Android Wireless Application Development	2	[]	14	1
279	2017-09-24 17:43:54.73486+00	31	Elliot Williams	2	[]	12	1
280	2017-09-26 01:25:33.330544+00	18	Web Site (author-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
281	2017-09-27 00:33:16.787282+00	26	Description (promotion-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
282	2017-09-27 00:33:54.380643+00	27	Promotion Start Date (promotion-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
283	2017-09-27 00:34:30.285139+00	25	Promotion Start Time (promotion-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
284	2017-09-27 00:34:59.28614+00	28	Promotion End Date (promotion-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
285	2017-09-27 00:36:52.211473+00	29	Promotion End Time (promotion-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
286	2017-09-27 00:51:58.956984+00	12	Address 1 (publisher-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
287	2017-09-27 00:54:33.155345+00	13	Address 2 (publisher-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
288	2017-09-27 00:57:56.923268+00	17	Postal Code (publisher-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
289	2017-09-27 01:00:52.471431+00	9	SKU (book-bottom)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
290	2017-09-27 01:01:06.379139+00	2	Published Date (book-center)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
291	2017-09-27 01:01:20.644941+00	7	Copyright Year (book-center)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
292	2017-09-27 01:01:44.593289+00	10	ISBN-10 (book-center)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
293	2017-09-27 01:01:56.268944+00	11	ISBN-13 (book-center)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
294	2017-09-27 01:02:18.98271+00	8	Number of Pages (book-top)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
295	2017-09-27 01:03:06.351618+00	24	Phone (publisher-center)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
296	2017-09-27 01:03:19.187006+00	21	Web Site (publisher-center)	2	[{"changed": {"fields": ["relation", "preferred_slug"]}}]	7	1
297	2017-09-27 01:39:27.95479+00	24	Android Wireless Application Development	2	[{"changed": {"object": "", "name": "Key Value", "fields": ["value"]}}, {"changed": {"object": "23", "name": "Key Value", "fields": ["value"]}}, {"changed": {"object": "", "name": "Key Value", "fields": ["value"]}}]	14	1
298	2017-09-27 01:40:10.748267+00	24	Android Wireless Application Development	2	[{"changed": {"object": "2", "name": "Key Value", "fields": ["value"]}}]	14	1
299	2017-09-27 01:40:48.080086+00	24	Android Wireless Application Development	2	[{"changed": {"object": "21", "name": "Key Value", "fields": ["value"]}}]	14	1
300	2017-09-27 01:41:31.057194+00	24	Android Wireless Application Development	2	[{"changed": {"object": "541", "name": "Key Value", "fields": ["value"]}}]	14	1
301	2017-12-10 00:27:55.003682+00	37	Software engineer	3		14	1
302	2017-12-11 15:42:48.900255+00	24	Android Wireless Application Development	3		14	1
303	2017-12-17 03:06:13.552585+00	18	John Wiley & Sons, Inc.	2	[]	13	1
304	2017-12-24 15:39:00.68268+00	38	Android Wireless Application Development	2	[]	14	1
305	2017-12-24 15:39:33.409011+00	33	Make: AVR Programming	2	[{"changed": {"fields": ["value"], "object": "0", "name": "Key Value"}}]	14	1
306	2017-12-24 15:40:04.234779+00	33	Make: AVR Programming	2	[{"changed": {"fields": ["value"], "object": "1", "name": "Key Value"}}]	14	1
307	2017-12-24 15:40:38.430201+00	33	Make: AVR Programming	2	[{"changed": {"fields": ["value"], "object": "2", "name": "Key Value"}}]	14	1
308	2017-12-28 01:09:47.372721+00	31	Elliot Williams	2	[]	12	1
309	2018-02-25 02:20:58.13193+00	42	Nishant Shukla	3		12	1
310	2018-02-25 02:21:05.755685+00	41	Nishant Shukla	3		12	1
311	2018-02-25 02:21:13.602394+00	40	Nishant Shukla	3		12	1
312	2018-02-25 02:21:20.416066+00	39	Nishant Shukla	3		12	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 312, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	dcolumns	dynamiccolumn
8	dcolumns	columncollection
9	dcolumns	collectionbase
10	dcolumns	keyvalue
11	books	promotion
12	books	author
13	books	publisher
14	books	book
15	sites	site
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 15, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2014-09-10 01:26:59.880275+00
2	auth	0001_initial	2014-09-10 01:27:00.562544+00
3	admin	0001_initial	2014-09-10 01:27:00.773773+00
4	sessions	0001_initial	2014-09-10 01:27:00.931372+00
5	admin	0002_logentry_remove_auto_add	2015-12-28 02:09:59.030505+00
6	contenttypes	0002_remove_content_type_name	2015-12-28 02:09:59.156705+00
7	auth	0002_alter_permission_name_max_length	2015-12-28 02:09:59.197606+00
8	auth	0003_alter_user_email_max_length	2015-12-28 02:09:59.2393+00
9	auth	0004_alter_user_username_opts	2015-12-28 02:09:59.2704+00
10	auth	0005_alter_user_last_login_null	2015-12-28 02:09:59.306482+00
11	auth	0006_require_contenttypes_0002	2015-12-28 02:09:59.314556+00
12	auth	0007_alter_validators_add_error_messages	2015-12-28 02:09:59.337897+00
13	sites	0001_initial	2015-12-31 02:38:22.020765+00
14	sites	0002_alter_domain_unique	2015-12-31 02:38:22.086236+00
15	dcolumns	0001_initial	2015-12-31 02:42:22.931497+00
16	books	0001_initial	2015-12-31 02:42:22.957045+00
17	dcolumns	0002_auto_20160130_1715	2016-01-30 22:16:17.992209+00
18	dcolumns	0003_auto_20160308_2158	2016-03-09 02:58:23.380322+00
19	dcolumns	0004_columncollection_related_model	2016-03-26 20:10:19.423378+00
20	auth	0008_alter_user_username_max_length	2017-09-24 01:42:37.823193+00
21	dcolumns	0005_auto_20160906_1706	2017-09-24 01:42:37.853103+00
22	dcolumns	0006_auto_20160906_1920	2017-09-24 01:42:37.867643+00
23	auth	0009_alter_user_last_name_max_length	2017-12-09 02:14:37.639831+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 23, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
tbzjnm2nu0hp28vh05d9t46fctyo41r3	YjI5NmFlNTYzZDE5YmFhNjIyZDUxYjI2NWJmNmMyY2FmNTJmMDhmZDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiOWFmYWIyMzY1MjUyNjM2ZmRkYmU5Y2UzMWRmOWVhZTEwY2I4NGY1MyIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=	2018-05-04 15:14:20.325375+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: books_author_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_author
    ADD CONSTRAINT books_author_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: books_book_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_book
    ADD CONSTRAINT books_book_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: books_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_promotion
    ADD CONSTRAINT books_promotion_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: books_publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_publisher
    ADD CONSTRAINT books_publisher_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: dcolumns_collectionbase_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_collectionbase
    ADD CONSTRAINT dcolumns_collectionbase_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_columncollection_dyn_columncollection_id_dynamicco_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dcolumns_columncollection_dyn_columncollection_id_dynamicco_key UNIQUE (columncollection_id, dynamiccolumn_id);


--
-- Name: dcolumns_columncollection_dynamic_column_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dcolumns_columncollection_dynamic_column_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_columncollection_name_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection
    ADD CONSTRAINT dcolumns_columncollection_name_key UNIQUE (name);


--
-- Name: dcolumns_columncollection_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection
    ADD CONSTRAINT dcolumns_columncollection_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_columncollection_related_model_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection
    ADD CONSTRAINT dcolumns_columncollection_related_model_key UNIQUE (related_model);


--
-- Name: dcolumns_dynamiccolumn_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_dynamiccolumn
    ADD CONSTRAINT dcolumns_dynamiccolumn_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_keyvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_keyvalue
    ADD CONSTRAINT dcolumns_keyvalue_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_user_groups_0e939a4f ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_user_groups_e8701ad4 ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_user_user_permissions_8373b171 ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: dcolumns_collectionbase_column_collection_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_collectionbase_column_collection_id ON public.dcolumns_collectionbase USING btree (column_collection_id);


--
-- Name: dcolumns_collectionbase_creator_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_collectionbase_creator_id ON public.dcolumns_collectionbase USING btree (creator_id);


--
-- Name: dcolumns_collectionbase_updater_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_collectionbase_updater_id ON public.dcolumns_collectionbase USING btree (updater_id);


--
-- Name: dcolumns_columncollection_creator_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_columncollection_creator_id ON public.dcolumns_columncollection USING btree (creator_id);


--
-- Name: dcolumns_columncollection_dynamic_column_columncollection_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_columncollection_dynamic_column_columncollection_id ON public.dcolumns_columncollection_dynamic_column USING btree (columncollection_id);


--
-- Name: dcolumns_columncollection_dynamic_column_dynamiccolumn_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_columncollection_dynamic_column_dynamiccolumn_id ON public.dcolumns_columncollection_dynamic_column USING btree (dynamiccolumn_id);


--
-- Name: dcolumns_columncollection_name_like; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_columncollection_name_like ON public.dcolumns_columncollection USING btree (name varchar_pattern_ops);


--
-- Name: dcolumns_columncollection_updater_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_columncollection_updater_id ON public.dcolumns_columncollection USING btree (updater_id);


--
-- Name: dcolumns_dynamiccolumn_creator_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_dynamiccolumn_creator_id ON public.dcolumns_dynamiccolumn USING btree (creator_id);


--
-- Name: dcolumns_dynamiccolumn_preferred_slug; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_dynamiccolumn_preferred_slug ON public.dcolumns_dynamiccolumn USING btree (preferred_slug);


--
-- Name: dcolumns_dynamiccolumn_preferred_slug_like; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_dynamiccolumn_preferred_slug_like ON public.dcolumns_dynamiccolumn USING btree (preferred_slug varchar_pattern_ops);


--
-- Name: dcolumns_dynamiccolumn_slug; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_dynamiccolumn_slug ON public.dcolumns_dynamiccolumn USING btree (slug);


--
-- Name: dcolumns_dynamiccolumn_slug_like; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_dynamiccolumn_slug_like ON public.dcolumns_dynamiccolumn USING btree (slug varchar_pattern_ops);


--
-- Name: dcolumns_dynamiccolumn_updater_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_dynamiccolumn_updater_id ON public.dcolumns_dynamiccolumn USING btree (updater_id);


--
-- Name: dcolumns_keyvalue_collection_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_keyvalue_collection_id ON public.dcolumns_keyvalue USING btree (collection_id);


--
-- Name: dcolumns_keyvalue_dynamic_column_id; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX dcolumns_keyvalue_dynamic_column_id ON public.dcolumns_keyvalue USING btree (dynamic_column_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: dcolumn
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_author_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_author
    ADD CONSTRAINT books_author_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES public.dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_book_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_book
    ADD CONSTRAINT books_book_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES public.dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_promotion_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_promotion
    ADD CONSTRAINT books_promotion_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES public.dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_publisher_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.books_publisher
    ADD CONSTRAINT books_publisher_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES public.dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dc_columncollection_id_f42856de_fk_dcolumns_columncollection_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dc_columncollection_id_f42856de_fk_dcolumns_columncollection_id FOREIGN KEY (columncollection_id) REFERENCES public.dcolumns_columncollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumn_dynamic_column_id_a06dd8eb_fk_dcolumns_dynamiccolumn_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_keyvalue
    ADD CONSTRAINT dcolumn_dynamic_column_id_a06dd8eb_fk_dcolumns_dynamiccolumn_id FOREIGN KEY (dynamic_column_id) REFERENCES public.dcolumns_dynamiccolumn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_collectionbase_column_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_collectionbase
    ADD CONSTRAINT dcolumns_collectionbase_column_collection_id_fkey FOREIGN KEY (column_collection_id) REFERENCES public.dcolumns_columncollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_dynamiccolumn_id_066bf886_fk_dcolumns_dynamiccolumn_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dcolumns_dynamiccolumn_id_066bf886_fk_dcolumns_dynamiccolumn_id FOREIGN KEY (dynamiccolumn_id) REFERENCES public.dcolumns_dynamiccolumn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_k_collection_id_c4318c38_fk_dcolumns_collectionbase_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.dcolumns_keyvalue
    ADD CONSTRAINT dcolumns_k_collection_id_c4318c38_fk_dcolumns_collectionbase_id FOREIGN KEY (collection_id) REFERENCES public.dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

