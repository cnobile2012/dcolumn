--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO dcolumn;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO dcolumn;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO dcolumn;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO dcolumn;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO dcolumn;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO dcolumn;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO dcolumn;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO dcolumn;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO dcolumn;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO dcolumn;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO dcolumn;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO dcolumn;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: books_author; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE books_author (
    collectionbase_ptr_id integer NOT NULL,
    name character varying(250) NOT NULL
);


ALTER TABLE public.books_author OWNER TO dcolumn;

--
-- Name: books_book; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE books_book (
    collectionbase_ptr_id integer NOT NULL,
    title character varying(250) NOT NULL
);


ALTER TABLE public.books_book OWNER TO dcolumn;

--
-- Name: books_promotion; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE books_promotion (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    name character varying(250) NOT NULL,
    description text NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone
);


ALTER TABLE public.books_promotion OWNER TO dcolumn;

--
-- Name: books_promotion_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE books_promotion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.books_promotion_id_seq OWNER TO dcolumn;

--
-- Name: books_promotion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE books_promotion_id_seq OWNED BY books_promotion.id;


--
-- Name: books_publisher; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE books_publisher (
    collectionbase_ptr_id integer NOT NULL,
    name character varying(250) NOT NULL
);


ALTER TABLE public.books_publisher OWNER TO dcolumn;

--
-- Name: dcolumns_collectionbase; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE dcolumns_collectionbase (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    column_collection_id integer NOT NULL
);


ALTER TABLE public.dcolumns_collectionbase OWNER TO dcolumn;

--
-- Name: dcolumns_collectionbase_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE dcolumns_collectionbase_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_collectionbase_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_collectionbase_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE dcolumns_collectionbase_id_seq OWNED BY dcolumns_collectionbase.id;


--
-- Name: dcolumns_columncollection; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE dcolumns_columncollection (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.dcolumns_columncollection OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_dynamic_column; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE dcolumns_columncollection_dynamic_column (
    id integer NOT NULL,
    columncollection_id integer NOT NULL,
    dynamiccolumn_id integer NOT NULL
);


ALTER TABLE public.dcolumns_columncollection_dynamic_column OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_dynamic_column_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE dcolumns_columncollection_dynamic_column_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_columncollection_dynamic_column_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_dynamic_column_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE dcolumns_columncollection_dynamic_column_id_seq OWNED BY dcolumns_columncollection_dynamic_column.id;


--
-- Name: dcolumns_columncollection_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE dcolumns_columncollection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_columncollection_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_columncollection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE dcolumns_columncollection_id_seq OWNED BY dcolumns_columncollection.id;


--
-- Name: dcolumns_dynamiccolumn; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE dcolumns_dynamiccolumn (
    id integer NOT NULL,
    updater_id integer NOT NULL,
    creator_id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    updated timestamp with time zone NOT NULL,
    active boolean NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    value_type integer NOT NULL,
    relation integer,
    required boolean NOT NULL,
    store_relation boolean NOT NULL,
    location integer NOT NULL,
    "order" smallint NOT NULL,
    preferred_slug character varying(50)
);


ALTER TABLE public.dcolumns_dynamiccolumn OWNER TO dcolumn;

--
-- Name: dcolumns_dynamiccolumn_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE dcolumns_dynamiccolumn_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_dynamiccolumn_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_dynamiccolumn_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE dcolumns_dynamiccolumn_id_seq OWNED BY dcolumns_dynamiccolumn.id;


--
-- Name: dcolumns_keyvalue; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE dcolumns_keyvalue (
    id integer NOT NULL,
    collection_id integer NOT NULL,
    dynamic_column_id integer NOT NULL,
    value text
);


ALTER TABLE public.dcolumns_keyvalue OWNER TO dcolumn;

--
-- Name: dcolumns_keyvalue_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE dcolumns_keyvalue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dcolumns_keyvalue_id_seq OWNER TO dcolumn;

--
-- Name: dcolumns_keyvalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE dcolumns_keyvalue_id_seq OWNED BY dcolumns_keyvalue.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO dcolumn;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO dcolumn;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO dcolumn;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO dcolumn;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO dcolumn;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: dcolumn
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO dcolumn;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dcolumn
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO dcolumn;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY books_promotion ALTER COLUMN id SET DEFAULT nextval('books_promotion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_collectionbase ALTER COLUMN id SET DEFAULT nextval('dcolumns_collectionbase_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_columncollection ALTER COLUMN id SET DEFAULT nextval('dcolumns_columncollection_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_columncollection_dynamic_column ALTER COLUMN id SET DEFAULT nextval('dcolumns_columncollection_dynamic_column_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_dynamiccolumn ALTER COLUMN id SET DEFAULT nextval('dcolumns_dynamiccolumn_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_keyvalue ALTER COLUMN id SET DEFAULT nextval('dcolumns_keyvalue_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can add permission	2	add_permission
5	Can change permission	2	change_permission
6	Can delete permission	2	delete_permission
7	Can add group	3	add_group
8	Can change group	3	change_group
9	Can delete group	3	delete_group
10	Can add user	4	add_user
11	Can change user	4	change_user
12	Can delete user	4	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add Dynamic Column	7	add_dynamiccolumn
20	Can change Dynamic Column	7	change_dynamiccolumn
21	Can delete Dynamic Column	7	delete_dynamiccolumn
22	Can add Column Collection	8	add_columncollection
23	Can change Column Collection	8	change_columncollection
24	Can delete Column Collection	8	delete_columncollection
25	Can add collection base	9	add_collectionbase
26	Can change collection base	9	change_collectionbase
27	Can delete collection base	9	delete_collectionbase
28	Can add Key Value	10	add_keyvalue
29	Can change Key Value	10	change_keyvalue
30	Can delete Key Value	10	delete_keyvalue
31	Can add Promotion	11	add_promotion
32	Can change Promotion	11	change_promotion
33	Can delete Promotion	11	delete_promotion
34	Can add Author	12	add_author
35	Can change Author	12	change_author
36	Can delete Author	12	delete_author
37	Can add Publisher	13	add_publisher
38	Can change Publisher	13	change_publisher
39	Can delete Publisher	13	delete_publisher
40	Can add Book	14	add_book
41	Can change Book	14	change_book
42	Can delete Book	14	delete_book
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('auth_permission_id_seq', 42, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$12000$6looOhRnhNuv$HUIALn4qiN8As1QDDMrejPZ15BnUt4Lcunh6xKaZC3Y=	2014-11-17 21:20:11.607535-05	t	dcolumn				t	t	2014-09-09 21:27:46.632029-04
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: books_author; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY books_author (collectionbase_ptr_id, name) FROM stdin;
5	John Iovine
6	Rajaram Regupathy
7	Richard Stones
8	Toby Segaran
\.


--
-- Data for Name: books_book; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY books_book (collectionbase_ptr_id, title) FROM stdin;
10	Beginning Linux Programming 2nd Edition
11	Bootstrap Yourself with Linux-USB Stack
12	Robots, Androids, and Animatrons
9	Collective Intelligence
\.


--
-- Data for Name: books_promotion; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY books_promotion (id, updater_id, creator_id, created, updated, active, name, description, start_date, end_date) FROM stdin;
1	1	1	2014-11-14 22:43:59.000693-05	2014-11-15 12:05:49.660551-05	t	50% Discount on "Collective Intelligence" eBook	Single day sale	2014-11-15 00:00:00-05	2014-11-16 00:00:00-05
2	1	1	2014-11-15 12:05:14.964966-05	2014-11-15 12:07:59.51599-05	f	50% Discount on "Robots, Androids, and Animatrons" eBook	Single day sale	2001-06-01 00:00:00-04	2001-06-02 00:00:00-04
\.


--
-- Name: books_promotion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('books_promotion_id_seq', 2, true);


--
-- Data for Name: books_publisher; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY books_publisher (collectionbase_ptr_id, name) FROM stdin;
2	Wrox Press Inc.
4	The McGraw-Hill Companies, Corp.
3	Cengage Learning, Inc.
1	O'Reilly Media, Inc.
\.


--
-- Data for Name: dcolumns_collectionbase; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY dcolumns_collectionbase (id, updater_id, creator_id, created, updated, active, column_collection_id) FROM stdin;
5	1	1	2014-11-14 23:48:58.377693-05	2014-11-14 23:48:58.377706-05	t	4
6	1	1	2014-11-14 23:50:12.471836-05	2014-11-14 23:50:12.471848-05	t	4
7	1	1	2014-11-14 23:51:25.789147-05	2014-11-14 23:51:25.78916-05	t	4
8	1	1	2014-11-14 23:52:02.800233-05	2014-11-14 23:52:02.800245-05	t	4
10	1	1	2014-11-15 11:01:20.214021-05	2014-11-15 11:09:37.503387-05	t	1
11	1	1	2014-11-15 11:21:46.33667-05	2014-11-15 11:21:46.336682-05	t	1
12	1	1	2014-11-15 11:29:29.712069-05	2014-11-15 12:07:48.130022-05	t	1
9	1	1	2014-11-15 00:21:22.781496-05	2014-11-15 16:01:50.121634-05	t	1
2	1	1	2014-11-14 23:24:22.586565-05	2014-11-28 18:25:27.07432-05	t	2
4	1	1	2014-11-14 23:41:16.508678-05	2014-11-28 18:26:07.660987-05	t	2
3	1	1	2014-11-14 23:27:56.169267-05	2014-11-28 18:26:23.140785-05	t	2
1	1	1	2014-11-14 22:47:21.049805-05	2014-11-28 18:26:34.415311-05	t	2
\.


--
-- Name: dcolumns_collectionbase_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('dcolumns_collectionbase_id_seq', 12, true);


--
-- Data for Name: dcolumns_columncollection; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY dcolumns_columncollection (id, updater_id, creator_id, created, updated, active, name) FROM stdin;
4	1	1	2014-09-10 21:16:50.206255-04	2014-09-10 21:16:50.206267-04	t	Author Current
1	1	1	2014-09-09 23:08:48.242518-04	2014-11-15 11:06:41.979289-05	t	Book Current
2	1	1	2014-09-10 15:53:48.019368-04	2014-11-28 17:42:16.087407-05	t	Publisher Current
\.


--
-- Data for Name: dcolumns_columncollection_dynamic_column; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY dcolumns_columncollection_dynamic_column (id, columncollection_id, dynamiccolumn_id) FROM stdin;
36	4	18
78	1	2
79	1	3
80	1	6
81	1	7
82	1	8
83	1	9
84	1	10
85	1	11
86	1	19
87	1	20
88	1	22
89	1	23
90	2	12
91	2	13
92	2	14
93	2	15
94	2	16
95	2	17
96	2	21
97	2	24
\.


--
-- Name: dcolumns_columncollection_dynamic_column_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('dcolumns_columncollection_dynamic_column_id_seq', 97, true);


--
-- Name: dcolumns_columncollection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('dcolumns_columncollection_id_seq', 4, true);


--
-- Data for Name: dcolumns_dynamiccolumn; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY dcolumns_dynamiccolumn (id, updater_id, creator_id, created, updated, active, name, slug, value_type, relation, required, store_relation, location, "order", preferred_slug) FROM stdin;
18	1	1	2014-09-10 20:55:56.897085-04	2014-11-14 22:22:30.722236-05	t	Web Site	author-url	6	\N	f	f	0	1	author-url
3	1	1	2014-09-09 22:11:00.117325-04	2014-11-15 11:13:40.117323-05	t	Abstract	abstract	7	\N	f	f	0	3	
8	1	1	2014-09-09 22:22:45.074184-04	2014-11-15 11:13:40.173682-05	t	Number of Pages	number-of-pages	5	\N	f	f	0	4	\N
12	1	1	2014-09-10 15:51:50.120345-04	2014-09-10 15:51:50.120362-04	t	Address 1	address-1	6	\N	f	f	0	1	\N
13	1	1	2014-09-10 15:52:12.799135-04	2014-09-10 15:52:12.799145-04	t	Address 2	address-2	6	\N	f	f	0	2	\N
14	1	1	2014-09-10 15:52:28.022632-04	2014-09-10 15:52:28.022641-04	t	City	city	6	\N	f	f	0	3	\N
15	1	1	2014-09-10 15:52:46.695098-04	2014-09-10 15:52:46.69511-04	t	State	state	6	\N	f	f	0	4	\N
16	1	1	2014-09-10 15:53:07.490947-04	2014-09-10 15:53:07.490964-04	t	Country	country	6	\N	f	f	0	5	\N
17	1	1	2014-09-10 15:56:03.291247-04	2014-09-10 15:56:03.291267-04	t	Postal Code	postal-code	6	\N	f	f	0	6	\N
9	1	1	2014-09-09 22:23:31.76202-04	2014-11-15 17:54:50.623035-05	t	Stock Unit ID	stock-unit-id	6	\N	f	f	2	3	stock-unit-id
22	1	1	2014-11-15 11:05:54.114142-05	2014-11-28 00:31:01.562448-05	t	Author	author	2	3	t	f	0	1	author
23	1	1	2014-11-15 11:06:18.473866-05	2014-11-28 00:33:46.963832-05	t	Publisher	publisher	2	4	t	f	0	2	publisher
6	1	1	2014-09-09 22:21:22.517697-04	2014-11-28 00:34:37.160353-05	t	Edition	edition	5	\N	f	f	1	1	edition
2	1	1	2014-09-09 22:10:21.507397-04	2014-11-28 00:35:13.50178-05	t	Published Date	published-date	3	\N	f	f	1	2	published-date
7	1	1	2014-09-09 22:21:54.515496-04	2014-11-28 00:36:01.900402-05	t	Copyright Year	copyright-year	5	\N	f	f	1	3	copyright-year
10	1	1	2014-09-09 22:24:22.178165-04	2014-11-28 00:36:52.604191-05	t	ISBN-10	isbn-10	6	\N	f	f	1	4	isbn-10
11	1	1	2014-09-09 22:24:43.505707-04	2014-11-28 00:37:32.333294-05	t	ISBN-13	isbn-13	6	\N	f	f	1	5	isbn-13
20	1	1	2014-09-12 22:44:04.159034-04	2014-11-28 00:38:02.839222-05	t	Language	language	2	1	f	f	1	6	language
19	1	1	2014-09-12 22:39:49.934608-04	2014-11-28 00:38:31.316959-05	t	Promotion	promotion	2	2	f	t	2	1	promotion
24	1	1	2014-11-28 17:41:38.181917-05	2014-11-28 17:41:38.182116-05	t	Phone	publisher-phone	6	\N	f	f	1	1	publisher-phone
21	1	1	2014-11-14 22:24:27.91203-05	2014-11-28 17:42:03.928598-05	t	Web Site	publisher-url	6	\N	f	f	1	2	publisher-url
\.


--
-- Name: dcolumns_dynamiccolumn_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('dcolumns_dynamiccolumn_id_seq', 24, true);


--
-- Data for Name: dcolumns_keyvalue; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY dcolumns_keyvalue (id, collection_id, dynamic_column_id, value) FROM stdin;
67	1	24	(800) 998-9938
68	4	13	
22	4	15	New York
7	2	12	29 S. LaSalle St.
8	2	13	Suite 520
9	2	14	Chicago
10	2	15	Illinois
11	2	16	USA
12	2	17	60603
42	10	22	7
43	10	23	2
34	10	6	2
35	10	8	1008
36	10	3	If you've installed Linux, or have access to a version of UNIX, you've probably gotten used to the environment and its configuration, but if you want to start programming, most Linux books leave you on your own. This book takes off where they stop, showing you how to make the most of the tools UNIX offers (which are included as standard with any distribution of Linux) and start programming UNIX for real.\r\n\r\nBeginning Linux Programming, 2nd Edition, concentrates on C programming, looking at the GNU tools, and the UNIX C libraries, to teach you step by step how to write, build, and debug serious application code. Throughout the book, you develop a fully featured CD Database application, allowing you to see the theory of each new topic applied to a real application. As well as handling basic file operations, input and output and dealing with the way UNIX handles data, you discover such advanced topics as inter-process communication, networking, and using CGI scripting to build a Web interface — all the elements of client-server programming. You are also introduced the GTK+ and you find out how to build rich graphical user interfaces for X with GNOME. Finally, there's an introduction to device drivers, to give you a window into the way the Linux kernel itself works.
37	10	20	2
38	10	2	2000-07-01
39	10	7	1999
40	10	10	1-861002-97-1
41	10	19	0
27	9	8	335
1	1	12	1005 Gravenstein Highway North
66	1	13	
2	1	14	Sebastopol
3	1	15	CA
4	1	16	United States
5	1	17	95472
23	4	16	USA
46	11	22	6
47	11	23	3
48	11	3	Learn to design, develop, and validate USB systems with ease, using this valuable resource that provides a detailed bootstrap session on the Linux-USB design and implementation. BOOTSTRAP YOURSELF WITH LINUX-USB STACK offers a tour of the Linux-USB stack, explaining how to develop drivers for USB device and host controllers on Linux. It moves on to explore the interfaces and data structures of a USB module with UML diagrams, concluding each chapter with a sample implementation that applies the information just covered. A comprehensive look at the various tools and methods available on Linux to validate a USB system is also provided. Using a straightforward writing style, this book is a powerful tool for anyone learning to develop a protocol stack with proper architecture and design, ultimately leading to better quality, maintainability, and testability.
49	11	8	320
50	11	2	2011-03-17
51	11	7	2012
52	11	10	1-4354-5786-2
53	11	11	978-1-4354-5786-7
54	11	20	2
55	11	19	0
56	12	22	5
57	12	23	4
58	12	3	Starting with the novice level and progressing to medium-level complexity; author John Iovine leads readers through the construction of 12 state-of-the-art robotics projects, which provides the foundations and experience for building advanced robotic projects. After outlining how to modify base platforms for locomotion, the author provides detailed information on various types of robotic sensors, including tilt, bump, and road and wall detectors. He illustrates how to implement two different types of robotic intelligence-expert and neural. The remainder of the book focuses on specific, hands-on projects, including a functional, life-like android hand created with a soft rubber material and nitinol wire; a robotic "insect" controlled with a single-board computer programmed in BASIC; and a land rover robot with telepresence systems.
59	12	8	332
60	12	6	2
61	12	2	2001-10-29
62	12	7	2002
63	12	10	0-07-137683-6
64	12	20	2
65	12	19	50% Discount on "Robots, Androids, and Animatrons" eBook
44	9	22	8
45	9	23	1
28	9	3	Want to tap the power behind search rankings, product recommendations, social bookmarking, and online matchmaking? This fascinating book demonstrates how you can build Web 2.0 applications to mine the enormous amount of data created by people on the Internet. With the sophisticated algorithms in this book, you can write smart programs to access interesting datasets from other web sites, collect data from users of your own applications, and analyze and understand the data once you've found it.
26	9	6	1
30	9	2	2007-08-01
31	9	7	2007
32	9	11	978-0-596-52932-1
29	9	20	2
33	9	19	50% Discount on "Collective Intelligence" eBook
24	4	17	10121-2298
69	4	24	(800) 262-4729
25	4	21	www.mheducation.com
14	3	12	20 Channel Center Street
70	3	13	
15	3	14	Boston
16	3	15	MA
17	3	16	United States
18	3	17	02210
71	3	24	(800) 354-9706
6	1	21	www.oreilly.com
20	4	12	Two Penn Plaza
21	4	14	New York
19	3	21	www.cengage.com
13	2	21	www.wrox.com
\.


--
-- Name: dcolumns_keyvalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('dcolumns_keyvalue_id_seq', 71, true);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2014-09-09 21:39:33.968614-04	1	Title	1		7	1
2	2014-09-09 22:10:21.519037-04	2	Published Date	1		7	1
3	2014-09-09 22:11:00.12927-04	3	Abstract	1		7	1
4	2014-09-09 22:11:31.766035-04	4	Purchase Date	1		7	1
5	2014-09-09 22:12:05.645248-04	4	Date Purchase	2	Changed name and relation.	7	1
6	2014-09-09 22:20:00.348272-04	4	Date Purchased	2	Changed name and relation.	7	1
7	2014-09-09 22:20:56.823019-04	5	Purchase Price	1		7	1
8	2014-09-09 22:21:22.528824-04	6	Edition	1		7	1
9	2014-09-09 22:21:54.525687-04	7	Copyright Year	1		7	1
10	2014-09-09 22:22:45.090261-04	8	Pages	1		7	1
11	2014-09-09 22:23:31.772054-04	9	Shelf ID	1		7	1
12	2014-09-09 22:24:22.188944-04	10	ISBN10	1		7	1
13	2014-09-09 22:24:43.512666-04	11	ISBN-13	1		7	1
14	2014-09-09 22:24:58.186149-04	10	ISBN-10	2	Changed name and relation.	7	1
15	2014-09-09 22:25:06.947606-04	10	ISBN-10	2	Changed relation.	7	1
16	2014-09-09 22:30:49.268616-04	6	Edition	2	Changed order.	7	1
17	2014-09-09 22:31:07.893867-04	7	Copyright Year	2	Changed order.	7	1
18	2014-09-09 22:32:20.872843-04	9	Shelf ID	2	Changed location and order.	7	1
19	2014-09-09 22:34:35.371096-04	6	Edition	2	Changed location and order.	7	1
20	2014-09-09 22:34:35.412151-04	2	Published Date	2	Changed location.	7	1
21	2014-09-09 22:34:35.454644-04	3	Abstract	2	Changed order.	7	1
22	2014-09-09 22:34:35.495753-04	7	Copyright Year	2	Changed location.	7	1
23	2014-09-09 22:34:35.528857-04	4	Date Purchased	2	Changed order.	7	1
24	2014-09-09 22:34:35.570874-04	5	Purchase Price	2	Changed order.	7	1
25	2014-09-09 22:34:35.621274-04	8	Pages	2	Changed order.	7	1
26	2014-09-09 22:34:35.662353-04	10	ISBN-10	2	Changed order.	7	1
27	2014-09-09 22:34:35.704116-04	11	ISBN-13	2	Changed order.	7	1
28	2014-09-09 22:34:35.754763-04	9	Shelf ID	2	Changed location and order.	7	1
29	2014-09-09 22:34:56.005179-04	10	ISBN-10	2	Changed location.	7	1
30	2014-09-09 22:34:56.055191-04	11	ISBN-13	2	Changed location.	7	1
31	2014-09-09 22:35:06.263815-04	4	Date Purchased	2	Changed location.	7	1
32	2014-09-09 22:35:55.033787-04	4	Date Purchased	2	Changed location and order.	7	1
33	2014-09-09 22:36:23.609573-04	5	Purchase Price	2	Changed location and order.	7	1
34	2014-09-09 22:36:23.651635-04	8	Pages	2	Changed order.	7	1
35	2014-09-09 22:37:27.878952-04	3	Abstract	2	Changed order.	7	1
36	2014-09-09 22:37:27.895989-04	9	Shelf ID	2	Changed order.	7	1
37	2014-09-09 22:37:27.938258-04	8	Pages	2	Changed order.	7	1
38	2014-09-09 22:37:27.988174-04	6	Edition	2	Changed location and order.	7	1
39	2014-09-09 22:38:05.906206-04	2	Published Date	2	Changed order.	7	1
40	2014-09-09 22:38:05.956198-04	7	Copyright Year	2	Changed order.	7	1
41	2014-09-09 22:38:06.006147-04	10	ISBN-10	2	Changed order.	7	1
42	2014-09-09 22:38:06.039966-04	11	ISBN-13	2	Changed order.	7	1
43	2014-09-09 23:08:48.289898-04	1	Book Current-2014-09-10T03:08:48.242546+00:00	1		8	1
44	2014-09-09 23:11:34.229577-04	1	Title	3		7	1
45	2014-09-09 23:11:53.005706-04	6	Edition	2	Changed order.	7	1
46	2014-09-09 23:11:53.04823-04	3	Abstract	2	Changed order.	7	1
47	2014-09-09 23:11:53.09747-04	9	Shelf ID	2	Changed order.	7	1
48	2014-09-09 23:11:53.130502-04	8	Pages	2	Changed order.	7	1
49	2014-09-10 10:46:16.808045-04	3	Abstract	2	Changed order.	7	1
50	2014-09-10 10:46:16.850615-04	9	Shelf ID	2	Changed order.	7	1
51	2014-09-10 10:46:16.900696-04	8	Pages	2	Changed order.	7	1
52	2014-09-10 10:46:59.389097-04	8	Number of Pages	2	Changed name and relation.	7	1
53	2014-09-10 15:51:50.134996-04	12	Address 1	1		7	1
54	2014-09-10 15:52:12.807505-04	13	Address 2	1		7	1
55	2014-09-10 15:52:28.032094-04	14	City	1		7	1
56	2014-09-10 15:52:46.703669-04	15	State	1		7	1
57	2014-09-10 15:53:07.507321-04	16	Country	1		7	1
58	2014-09-10 15:53:48.056495-04	2	Publisher Current-2014-09-10T19:53:48.019384+00:00	1		8	1
59	2014-09-10 15:56:03.301322-04	17	Postal Code	1		7	1
60	2014-09-10 15:56:28.859398-04	2	Publisher Current-2014-09-10T19:56:28.821174+00:00	2	Changed dynamic_column.	8	1
61	2014-09-10 18:55:25.277139-04	2	Publisher Current-2014-09-10T22:55:25.240698+00:00	2	No fields changed.	8	1
62	2014-09-10 20:43:30.420769-04	2	Publisher Current-2014-09-11T00:43:30.383947+00:00	2	No fields changed.	8	1
63	2014-09-10 20:55:56.906485-04	18	URL	1		7	1
64	2014-09-10 21:12:37.149046-04	3	Author Current-2014-09-11T01:12:37.115966+00:00	1		8	1
65	2014-09-10 21:15:10.660547-04	3	Author Current-2014-09-11T01:12:37.115966+00:00	3		8	1
66	2014-09-10 21:16:50.245355-04	4	Author Current-2014-09-11T01:16:50.206267+00:00	1		8	1
67	2014-09-11 12:23:22.658521-04	18	Web Site URL	2	Changed name and relation.	7	1
68	2014-09-12 22:39:49.946046-04	19	Promotion	1		7	1
69	2014-09-12 22:40:27.27698-04	1	Book Current-2014-09-13T02:40:27.236641+00:00	2	Changed dynamic_column.	8	1
70	2014-09-12 22:40:35.434702-04	1	Book Current-2014-09-13T02:40:35.396951+00:00	2	No fields changed.	8	1
71	2014-09-12 22:41:19.991834-04	19	Promotion	2	Changed relation, location and order.	7	1
72	2014-09-12 22:44:04.169945-04	20	Language	1		7	1
73	2014-09-12 22:44:29.491736-04	1	Book Current-2014-09-13T02:44:29.456317+00:00	2	Changed dynamic_column.	8	1
74	2014-11-11 20:35:41.647318-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
75	2014-11-11 20:35:51.627896-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
76	2014-11-11 20:36:39.075042-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
77	2014-11-11 20:36:52.681611-05	18	Web Site URL POOP	2	Changed name and relation.	7	1
78	2014-11-11 20:37:05.700478-05	18	Web Site URL	2	Changed name and relation.	7	1
79	2014-11-11 20:37:43.143402-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
80	2014-11-11 20:37:53.207807-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
81	2014-11-11 20:38:08.176637-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
82	2014-11-14 22:21:47.607424-05	18	Web Site URL	2	Changed relation and preferred_slug.	7	1
83	2014-11-14 22:22:30.731718-05	18	Web Site	2	Changed name and relation.	7	1
84	2014-11-14 22:24:27.933509-05	21	Web Site	1		7	1
85	2014-11-14 22:25:08.683207-05	2	Publisher Current-2014-11-15T03:25:08.588231+00:00	2	Changed dynamic_column.	8	1
86	2014-11-14 22:43:59.039989-05	1	50% Discount on eBook-2014-11-15T00:00:00-05:00	1		11	1
87	2014-11-14 22:47:21.088933-05	1	O'Reilly Media, Inc.	1		13	1
88	2014-11-15 00:12:39.401601-05	3	Abstract	2	Changed relation.	7	1
89	2014-11-15 00:13:56.652186-05	19	Promotion	2	Changed relation.	7	1
90	2014-11-15 01:20:35.390633-05	4	Date Purchased	3		7	1
91	2014-11-15 01:20:35.429701-05	5	Purchase Price	3		7	1
92	2014-11-15 01:20:54.180662-05	19	Promotion	2	Changed order.	7	1
93	2014-11-15 11:05:54.12218-05	22	Author	1		7	1
94	2014-11-15 11:06:18.481195-05	23	Publisher	1		7	1
95	2014-11-15 11:06:42.018962-05	1	Book Current-2014-11-15T16:06:41.979289+00:00	2	Changed dynamic_column.	8	1
96	2014-11-15 11:08:58.75954-05	6	Edition	2	Changed order.	7	1
97	2014-11-15 11:08:58.792999-05	8	Number of Pages	2	Changed order.	7	1
98	2014-11-15 11:08:58.826154-05	3	Abstract	2	Changed order.	7	1
99	2014-11-15 11:08:58.859346-05	9	Shelf ID	2	Changed order.	7	1
100	2014-11-15 11:08:58.901347-05	20	Language	2	Changed order.	7	1
101	2014-11-15 11:11:25.533571-05	6	Edition	2	Changed location and order.	7	1
102	2014-11-15 11:11:25.575653-05	2	Published Date	2	Changed order.	7	1
103	2014-11-15 11:11:25.608578-05	7	Copyright Year	2	Changed order.	7	1
104	2014-11-15 11:11:25.65091-05	10	ISBN-10	2	Changed order.	7	1
105	2014-11-15 11:11:25.691863-05	11	ISBN-13	2	Changed order.	7	1
106	2014-11-15 11:12:01.376945-05	8	Number of Pages	2	Changed order.	7	1
107	2014-11-15 11:12:01.427863-05	3	Abstract	2	Changed order.	7	1
108	2014-11-15 11:13:01.571778-05	20	Language	2	Changed location and order.	7	1
109	2014-11-15 11:13:40.149196-05	3	Abstract	2	Changed order.	7	1
110	2014-11-15 11:13:40.190133-05	8	Number of Pages	2	Changed order.	7	1
111	2014-11-15 11:13:40.231683-05	9	Shelf ID	2	Changed order.	7	1
112	2014-11-15 11:13:56.666167-05	9	Shelf ID	2	Changed location and order.	7	1
113	2014-11-15 12:02:54.29079-05	1	50% Discount on "Collective Intelligence" eBook-2014-11-15T00:00:00-05:00	2	Changed name.	11	1
114	2014-11-15 12:05:14.976081-05	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T00:00:00-04:00	1		11	1
115	2014-11-15 12:05:49.668228-05	1	50% Discount on "Collective Intelligence" eBook-2014-11-15T00:00:00-05:00	2	Changed description.	11	1
116	2014-11-15 12:06:04.531394-05	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T00:00:00-04:00	2	Changed description.	11	1
117	2014-11-15 12:07:38.282123-05	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T04:00:00+00:00	2	Changed active.	11	1
118	2014-11-15 12:07:59.541262-05	2	50% Discount on "Robots, Androids, and Animatrons" eBook-2001-06-01T04:00:00+00:00	2	Changed active.	11	1
119	2014-11-15 17:54:50.631012-05	9	Stock Unit ID	2	Changed name, relation and preferred_slug.	7	1
120	2014-11-28 00:31:01.705038-05	22	Author	2	Changed relation and preferred_slug.	7	1
121	2014-11-28 00:33:46.974891-05	23	Publisher	2	Changed relation and preferred_slug.	7	1
122	2014-11-28 00:34:37.171441-05	6	Edition	2	Changed relation and preferred_slug.	7	1
123	2014-11-28 00:35:13.513823-05	2	Published Date	2	Changed relation and preferred_slug.	7	1
124	2014-11-28 00:36:01.908415-05	7	Copyright Year	2	Changed relation and preferred_slug.	7	1
125	2014-11-28 00:36:52.615362-05	10	ISBN-10	2	Changed relation and preferred_slug.	7	1
126	2014-11-28 00:37:32.341804-05	11	ISBN-13	2	Changed relation and preferred_slug.	7	1
127	2014-11-28 00:38:02.846827-05	20	Language	2	Changed relation and preferred_slug.	7	1
128	2014-11-28 00:38:31.327903-05	19	Promotion	2	Changed relation and preferred_slug.	7	1
129	2014-11-28 17:41:38.351454-05	24	Phone	1		7	1
130	2014-11-28 17:42:03.965217-05	21	Web Site	2	Changed location and order.	7	1
131	2014-11-28 17:42:16.169207-05	2	Publisher Current-2014-11-28T22:42:16.087407+00:00	2	Changed dynamic_column.	8	1
132	2014-11-28 18:10:08.722458-05	2	Wrox Press Inc.	2	Changed value for Key Value "http://www.wrox.com".	13	1
133	2014-11-28 18:25:27.098331-05	2	Wrox Press Inc.	2	Changed value for Key Value "www.wrox.com".	13	1
134	2014-11-28 18:26:07.68691-05	4	The McGraw-Hill Companies, Corp.	2	Changed value for Key Value "www.mheducation.com".	13	1
135	2014-11-28 18:26:23.171496-05	3	Cengage Learning, Inc.	2	Changed value for Key Value "www.cengage.com".	13	1
136	2014-11-28 18:26:34.444478-05	1	O'Reilly Media, Inc.	2	Changed value for Key Value "www.oreilly.com".	13	1
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 136, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	log entry	admin	logentry
2	permission	auth	permission
3	group	auth	group
4	user	auth	user
5	content type	contenttypes	contenttype
6	session	sessions	session
7	Dynamic Column	dcolumns	dynamiccolumn
8	Column Collection	dcolumns	columncollection
9	collection base	dcolumns	collectionbase
10	Key Value	dcolumns	keyvalue
11	Promotion	books	promotion
12	Author	books	author
13	Publisher	books	publisher
14	Book	books	book
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('django_content_type_id_seq', 14, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2014-09-09 21:26:59.880275-04
2	auth	0001_initial	2014-09-09 21:27:00.562544-04
3	admin	0001_initial	2014-09-09 21:27:00.773773-04
4	sessions	0001_initial	2014-09-09 21:27:00.931372-04
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dcolumn
--

SELECT pg_catalog.setval('django_migrations_id_seq', 4, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: dcolumn
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
i1e2g8r032d5qcl9u6rp9tsfjcilnjoy	ZjFkMjdiMjM5MzViY2M2ZDdlMjhlODdlM2YxNjllNDc5MzkxNWRhNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjY3MDgyZmQwMWJmZTQ0ZGFkZWU2MGM2M2MwNzE2M2U2ODI5MDEyZjUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2014-09-23 21:29:58.960989-04
7lzhuo7sah0bzn3857svmrvgsxzvh181	MWU4ZmJjZmM2N2RmMmEzOWVmOGVhYzBhYjQzMGZiYjNlMjlmZjllYTp7fQ==	2014-09-29 20:28:28.634564-04
687ukhb394vwc0mvte8bymdek2friqc3	ZjFkMjdiMjM5MzViY2M2ZDdlMjhlODdlM2YxNjllNDc5MzkxNWRhNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjY3MDgyZmQwMWJmZTQ0ZGFkZWU2MGM2M2MwNzE2M2U2ODI5MDEyZjUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2014-10-08 20:29:21.762131-04
cuheiec1aq8itgdck4pq4fmp1eiqg7yx	ZjFkMjdiMjM5MzViY2M2ZDdlMjhlODdlM2YxNjllNDc5MzkxNWRhNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjY3MDgyZmQwMWJmZTQ0ZGFkZWU2MGM2M2MwNzE2M2U2ODI5MDEyZjUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2014-10-19 10:03:40.040495-04
jo0jmgokf0tawwyw2o4zkccqnbycltzi	ZjFkMjdiMjM5MzViY2M2ZDdlMjhlODdlM2YxNjllNDc5MzkxNWRhNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjY3MDgyZmQwMWJmZTQ0ZGFkZWU2MGM2M2MwNzE2M2U2ODI5MDEyZjUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2014-11-02 09:47:10.069428-05
n5kmzqc84uq8e866u5qltqtpyl0r5dkb	ZjFkMjdiMjM5MzViY2M2ZDdlMjhlODdlM2YxNjllNDc5MzkxNWRhNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjY3MDgyZmQwMWJmZTQ0ZGFkZWU2MGM2M2MwNzE2M2U2ODI5MDEyZjUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2014-11-16 17:22:46.366548-05
rgy29gd51k1nv3w6h7em05jwh88gj5wt	ZjFkMjdiMjM5MzViY2M2ZDdlMjhlODdlM2YxNjllNDc5MzkxNWRhNjp7Il9hdXRoX3VzZXJfaGFzaCI6IjY3MDgyZmQwMWJmZTQ0ZGFkZWU2MGM2M2MwNzE2M2U2ODI5MDEyZjUiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2014-12-01 21:20:11.677402-05
\.


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: books_author_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY books_author
    ADD CONSTRAINT books_author_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: books_book_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY books_book
    ADD CONSTRAINT books_book_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: books_promotion_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY books_promotion
    ADD CONSTRAINT books_promotion_pkey PRIMARY KEY (id);


--
-- Name: books_publisher_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY books_publisher
    ADD CONSTRAINT books_publisher_pkey PRIMARY KEY (collectionbase_ptr_id);


--
-- Name: dcolumns_collectionbase_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_collectionbase
    ADD CONSTRAINT dcolumns_collectionbase_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_columncollection_dyn_columncollection_id_dynamicco_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dcolumns_columncollection_dyn_columncollection_id_dynamicco_key UNIQUE (columncollection_id, dynamiccolumn_id);


--
-- Name: dcolumns_columncollection_dynamic_column_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dcolumns_columncollection_dynamic_column_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_columncollection_name_key; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_columncollection
    ADD CONSTRAINT dcolumns_columncollection_name_key UNIQUE (name);


--
-- Name: dcolumns_columncollection_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_columncollection
    ADD CONSTRAINT dcolumns_columncollection_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_dynamiccolumn_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_dynamiccolumn
    ADD CONSTRAINT dcolumns_dynamiccolumn_pkey PRIMARY KEY (id);


--
-- Name: dcolumns_keyvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY dcolumns_keyvalue
    ADD CONSTRAINT dcolumns_keyvalue_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: dcolumn; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: books_promotion_creator_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX books_promotion_creator_id ON books_promotion USING btree (creator_id);


--
-- Name: books_promotion_updater_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX books_promotion_updater_id ON books_promotion USING btree (updater_id);


--
-- Name: dcolumns_collectionbase_column_collection_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_collectionbase_column_collection_id ON dcolumns_collectionbase USING btree (column_collection_id);


--
-- Name: dcolumns_collectionbase_creator_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_collectionbase_creator_id ON dcolumns_collectionbase USING btree (creator_id);


--
-- Name: dcolumns_collectionbase_updater_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_collectionbase_updater_id ON dcolumns_collectionbase USING btree (updater_id);


--
-- Name: dcolumns_columncollection_creator_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_columncollection_creator_id ON dcolumns_columncollection USING btree (creator_id);


--
-- Name: dcolumns_columncollection_dynamic_column_columncollection_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_columncollection_dynamic_column_columncollection_id ON dcolumns_columncollection_dynamic_column USING btree (columncollection_id);


--
-- Name: dcolumns_columncollection_dynamic_column_dynamiccolumn_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_columncollection_dynamic_column_dynamiccolumn_id ON dcolumns_columncollection_dynamic_column USING btree (dynamiccolumn_id);


--
-- Name: dcolumns_columncollection_name_like; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_columncollection_name_like ON dcolumns_columncollection USING btree (name varchar_pattern_ops);


--
-- Name: dcolumns_columncollection_updater_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_columncollection_updater_id ON dcolumns_columncollection USING btree (updater_id);


--
-- Name: dcolumns_dynamiccolumn_creator_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_dynamiccolumn_creator_id ON dcolumns_dynamiccolumn USING btree (creator_id);


--
-- Name: dcolumns_dynamiccolumn_slug; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_dynamiccolumn_slug ON dcolumns_dynamiccolumn USING btree (slug);


--
-- Name: dcolumns_dynamiccolumn_slug_like; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_dynamiccolumn_slug_like ON dcolumns_dynamiccolumn USING btree (slug varchar_pattern_ops);


--
-- Name: dcolumns_dynamiccolumn_updater_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_dynamiccolumn_updater_id ON dcolumns_dynamiccolumn USING btree (updater_id);


--
-- Name: dcolumns_keyvalue_collection_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_keyvalue_collection_id ON dcolumns_keyvalue USING btree (collection_id);


--
-- Name: dcolumns_keyvalue_dynamic_column_id; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX dcolumns_keyvalue_dynamic_column_id ON dcolumns_keyvalue USING btree (dynamic_column_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: dcolumn; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_author_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY books_author
    ADD CONSTRAINT books_author_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_book_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY books_book
    ADD CONSTRAINT books_book_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: books_publisher_collectionbase_ptr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY books_publisher
    ADD CONSTRAINT books_publisher_collectionbase_ptr_id_fkey FOREIGN KEY (collectionbase_ptr_id) REFERENCES dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: columncollection_id_refs_id_bf9efeaa; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT columncollection_id_refs_id_bf9efeaa FOREIGN KEY (columncollection_id) REFERENCES dcolumns_columncollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_collectionbase_column_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_collectionbase
    ADD CONSTRAINT dcolumns_collectionbase_column_collection_id_fkey FOREIGN KEY (column_collection_id) REFERENCES dcolumns_columncollection(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_columncollection_dynamic_column_dynamiccolumn_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_columncollection_dynamic_column
    ADD CONSTRAINT dcolumns_columncollection_dynamic_column_dynamiccolumn_id_fkey FOREIGN KEY (dynamiccolumn_id) REFERENCES dcolumns_dynamiccolumn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_keyvalue_collection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_keyvalue
    ADD CONSTRAINT dcolumns_keyvalue_collection_id_fkey FOREIGN KEY (collection_id) REFERENCES dcolumns_collectionbase(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dcolumns_keyvalue_dynamic_column_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY dcolumns_keyvalue
    ADD CONSTRAINT dcolumns_keyvalue_dynamic_column_id_fkey FOREIGN KEY (dynamic_column_id) REFERENCES dcolumns_dynamiccolumn(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: dcolumn
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

